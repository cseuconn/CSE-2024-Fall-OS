#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "kernel/filesystem.h"

// test the buffer cache operations
void test_buffer_operations(void) {
   printf("\n\033[33mRunning buffer cache tests...\033[0m\n");
   
   // initialize the buffer cache
   buffer_init();
   printf("1. Testing single buffer operations:\n");
   
   // test single buffer
   buffer_t* buf1 = buffer_get(1);
   assert(buf1 != NULL);
   printf("   - Buffer allocation: success\n");
   
   // test buffer data and dirty marking
   memset(buf1->data, 'A', BLOCK_SIZE);
   buffer_mark_dirty(buf1);
   printf("   - Buffer write and dirty marking: success\n");
   
   // test cache hit
   buffer_t* buf2 = buffer_get(1);
   assert(buf2 == buf1);
   printf("   - Buffer cache hit: success\n");
   
   printf("\n2. Testing buffer cache capacity:\n");
   // test filling buffer cache
   buffer_t* buffers[NUM_BUFFERS - 1];
   printf("   - Allocating %d buffers: ", NUM_BUFFERS - 1);
   for (int i = 0; i < NUM_BUFFERS - 1; i++) {
       buffers[i] = buffer_get(i + 2);
       assert(buffers[i] != NULL);
       if (i % 10 == 0) printf(".");  // progress indicator
   }
   printf(" done\n");
   
   // test overflow
   buffer_t* overflow = buffer_get(NUM_BUFFERS + 1);
   assert(overflow == NULL);
   printf("   - Buffer overflow handling: success\n");
   
   printf("\n3. Testing buffer release:\n");
   printf("   - Releasing %d buffers: ", NUM_BUFFERS - 1);
   for (int i = 0; i < NUM_BUFFERS - 1; i++) {
       buffer_release(buffers[i]);
       if (i % 10 == 0) printf(".");  // progress indicator
   }
   printf(" done\n");
   
   buffer_release(buf1);
   printf("   - Final buffer release: success\n");
   
   printf("\n\033[32mBuffer cache tests passed!\033[0m\n\n");
}

// test the inode operations
void test_inode_operations(void) {
   printf("\033[33mRunning inode tests...\033[0m\n");
   
   // initialize the inode system
   inode_init();
   
   // test inode allocation
   uint32_t inode1 = inode_allocate();
   assert(inode1 != (uint32_t)-1);
   printf("Successfully allocated inode %u\n", inode1);
   
   // test block allocation and retrieval
   for (int i = 0; i < DIRECT_BLOCKS; i++) {
       assert(inode_add_block(inode1, i) == 0);
       assert(inode_get_block(inode1, i) == i);
   }
   printf("Successfully allocated and verified all direct blocks\n");
   
   // test block allocation overflow
   assert(inode_add_block(inode1, DIRECT_BLOCKS) < 0);
   printf("Successfully prevented block overflow\n");
   
   // test size operations
   size_t test_size = 1024;
   inode_update_size(inode1, test_size);
   assert(inode_get_size(inode1) == test_size);
   printf("Successfully updated and verified inode size\n");
   
   // test inode freeing and reallocation
   inode_free(inode1);
   uint32_t inode2 = inode_allocate();
   assert(inode2 != (uint32_t)-1);
   printf("Successfully freed and reallocated inode\n");
   
   printf("\033[32mInode tests passed!\033[0m\n\n");
}

// test the file operations
void test_file_operations(void) {
   printf("\033[33mRunning file operations tests...\033[0m\n");
   
   // initialize the file system
   assert(fs_init() == 0);
   
   // test single file operations first
   assert(fs_create("/test.txt", FILE_TYPE_REGULAR) == 0);
   int fd = fs_open("/test.txt", O_WRITE);
   assert(fd >= 0);
   printf("Successfully created and opened file\n");
   
   // test write operation
   const char data[] = "Hello, World!";
   ssize_t bytes_written = fs_write(fd, data, strlen(data));
   assert(bytes_written >= 0 && (size_t)bytes_written == strlen(data));
   printf("Successfully wrote %zd bytes\n", bytes_written);
   
   // test seek and read
   assert(fs_seek(fd, 0, SEEK_SET) == 0);
   char buffer[64] = {0};
   ssize_t bytes_read = fs_read(fd, buffer, strlen(data));
   assert(bytes_read >= 0 && (size_t)bytes_read == strlen(data));
   assert(memcmp(buffer, data, strlen(data)) == 0);
   printf("Successfully read back %zd bytes\n", bytes_read);
   
   // test partial read/write
   const char more_data[] = "More data";
   assert(fs_seek(fd, bytes_written, SEEK_SET) == 0);  // seek to end
   bytes_written = fs_write(fd, more_data, strlen(more_data));
   assert(bytes_written >= 0 && (size_t)bytes_written == strlen(more_data));
   printf("Successfully appended %zd more bytes\n", bytes_written);
   
   // read partial data
   assert(fs_seek(fd, 5, SEEK_SET) == 0);  // seek to middle
   char small_buf[5];
   bytes_read = fs_read(fd, small_buf, sizeof(small_buf));
   assert(bytes_read == 5);
   printf("Successfully read %zd bytes from middle\n", bytes_read);
   
   // test error conditions
   assert(fs_read(-1, buffer, sizeof(buffer)) < 0);  // invalid fd
   assert(fs_write(-1, data, strlen(data)) < 0);     // invalid fd
   assert(fs_read(fd, NULL, 10) <= 0);               // invalid buffer
   assert(fs_write(fd, NULL, 10) <= 0);              // invalid buffer
   printf("Successfully handled error conditions\n");
   
   // close and cleanup
   assert(fs_close(fd) == 0);
   assert(fs_unlink("/test.txt") == 0);
   printf("Successfully closed and removed file\n");
   
   // clean up the file system
   fs_cleanup();
   printf("\033[32mFile operations tests passed!\033[0m\n\n");
}

// main entry point
int main(void) {
   printf("\n=== Starting File System Component Tests ===\n");
   
   // run the tests
   test_buffer_operations();
   test_inode_operations();
   test_file_operations();
   
   printf("=== All File System Component Tests Passed ===\n\n");
   return 0;
}