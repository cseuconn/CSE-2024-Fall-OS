#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "kernel/filesystem.h"

// test the directory operations
void test_directory_operations(void) {
   printf("\n\033[33mRunning directory operations tests...\033[0m\n");
   
   // initialize the file system
   assert(fs_init() == 0);
   printf("Filesystem initialized\n");
   
   // test directory creation
   assert(fs_mkdir("/testdir") == 0);
   printf("Created test directory\n");
   
   // test file creation in directory
   assert(fs_create("/testdir/file1.txt", FILE_TYPE_REGULAR) == 0);
   assert(fs_create("/testdir/file2.txt", FILE_TYPE_REGULAR) == 0);
   printf("Created files in directory\n");
   
   // test directory opening and listing
   int dir_fd = fs_open("/testdir", O_READ | O_DIRECTORY);
   assert(dir_fd >= 0);
   
   dir_entry_t entry;
   int file_count = 0;
   while (fs_readdir(dir_fd, &entry) > 0) {
       printf("Found file: %s\n", entry.name);
       file_count++;
   }
   assert(file_count == 2);
   printf("Successfully listed directory contents\n");
   
   // test directory close
   assert(fs_close(dir_fd) == 0);
   printf("Closed directory\n");
   
   // test removing non-empty directory (should fail)
   assert(fs_rmdir("/testdir") == -1);
   printf("Prevented removal of non-empty directory\n");
   
   // test removing files
   assert(fs_unlink("/testdir/file1.txt") == 0);
   assert(fs_unlink("/testdir/file2.txt") == 0);
   printf("Removed files from directory\n");
   
   // test removing empty directory (should succeed)
   assert(fs_rmdir("/testdir") == 0);
   printf("Successfully removed empty directory\n");
   
   // test error conditions
   assert(fs_mkdir("/testdir") == 0);
   assert(fs_mkdir("/testdir") == -1);  // already exists
   assert(fs_rmdir("/nonexistent") == -1);  // doesn't exist
   assert(fs_rmdir("/testdir") == 0);
   printf("Successfully handled directory error conditions\n");
   
   // clean up the file system
   fs_cleanup();
   printf("\033[32mDirectory operations tests passed!\033[0m\n\n");
}

// main entry point
int main(void) {
   printf("\n=== Starting Directory Operations Tests ===\n");
   
   // run the directory operations test
   test_directory_operations();
   
   printf("=== Directory Operations Tests Completed ===\n\n");
   return 0;
}