#include "kernel/paging.h"
#include <stdio.h>
#include <assert.h>

void test_paging_initialization() {
    printf("Running paging initialization test...\n");
    paging_init(10); // Initialize paging system with 10 entries
    printf("Paging initialization test passed.\n");
}

void test_add_page_table_entry() {
    printf("Running add page table entry test...\n");
    void *virtual_address = (void *)0x1000;
    void *physical_address = (void *)0x2000;
    
    add_page_table_entry(virtual_address, physical_address);
    void *result = get_physical_address(virtual_address);
    assert(result == physical_address);
    printf("Added and verified page table entry: VA %p -> PA %p\n", virtual_address, result);
    printf("Add page table entry test passed.\n");
}

void test_remove_page_table_entry() {
    printf("Running remove page table entry test...\n");
    void *virtual_address = (void *)0x1000;

    remove_page_table_entry(virtual_address);
    void *result = get_physical_address(virtual_address);
    assert(result == NULL);
    printf("Removed page table entry for VA %p and verified it is no longer valid.\n", virtual_address);
    printf("Remove page table entry test passed.\n");
}

void test_get_physical_address() {
    printf("Running get physical address test...\n");
    void *virtual_address = (void *)0x3000;
    void *physical_address = (void *)0x4000;

    add_page_table_entry(virtual_address, physical_address);
    void *result = get_physical_address(virtual_address);
    assert(result == physical_address);
    printf("Verified physical address for VA %p -> PA %p\n", virtual_address, result);

    // Test invalid virtual address
    result = get_physical_address((void *)0x5000);
    assert(result == NULL);
    printf("Verified that physical address for invalid VA %p is NULL.\n", (void *)0x5000);

    printf("Get physical address test passed.\n");
}

int main() {
    test_paging_initialization();
    test_add_page_table_entry();
    test_remove_page_table_entry();
    test_get_physical_address();
    printf("All paging tests passed successfully.\n");
    return 0;
}
