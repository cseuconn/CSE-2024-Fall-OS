#include "kernel/vmm.h"
#include "kernel/pmm.h"
#include "kernel/paging.h"
#include <stdio.h>
#include <assert.h>

void test_vmm_initialization() {
    printf("Running VMM initialization test...\n");
    vmm_init();
    printf("VMM initialization test passed.\n");
}

void test_vmm_allocate_page() {
    printf("Running VMM allocate page test...\n");
    void *page1 = vmm_allocate_page();
    assert(page1 != NULL);
    printf("Allocated page at %p\n", page1);

    void *page2 = vmm_allocate_page();
    assert(page2 != NULL);
    printf("Allocated another page at %p\n", page2);

    printf("VMM allocate page test passed.\n");
}

void test_vmm_free_page() {
    printf("Running VMM free page test...\n");
    void *page = vmm_allocate_page();
    assert(page != NULL);
    printf("Allocated page at %p\n", page);

    vmm_free_page(page);
    printf("Freed page at %p\n", page);

    // Try allocating again to check if freed memory is reusable
    void *new_page = vmm_allocate_page();
    assert(new_page != NULL);
    printf("Re-allocated page at %p\n", new_page);

    printf("VMM free page test passed.\n");
}

void test_vmm_translate() {
    printf("Running VMM translate test...\n");
    void *page = vmm_allocate_page();
    if (page == NULL) {
        printf("No more virtual pages available, skipping translate test.\n");
        return;
    }

    void *physical_address = vmm_translate(page);
    if (physical_address == NULL) {
        printf("No physical frame available for translation, skipping test.\n");
        return;
    }

    printf("Translated virtual address %p to physical address %p\n", page, physical_address);

    // Test translation for an address that wasn't allocated
    void *invalid_address = (void *)0xDEADBEEF;
    void *result = vmm_translate(invalid_address);
    assert(result == NULL);
    printf("Translation of invalid address %p returned NULL as expected.\n", invalid_address);

    printf("VMM translate test passed.\n");
}


void test_vmm_edge_cases() {
    printf("Running VMM edge cases test...\n");
    // Allocate all pages until full
    while (vmm_allocate_page() != NULL);
    printf("Allocated all available virtual memory pages.\n");

    // Try to allocate one more page and expect NULL
    void *extra_page = vmm_allocate_page();
    assert(extra_page == NULL);
    printf("No more pages available, allocation returned NULL as expected.\n");

    printf("VMM edge cases test passed.\n");
}

int main() {
    test_vmm_initialization();
    test_vmm_allocate_page();
    test_vmm_free_page();
    test_vmm_translate();
    test_vmm_edge_cases();
    printf("All VMM tests passed successfully.\n");
    return 0;
}
