#include "kernel/pmm.h"
#include <stdio.h>
#include <assert.h>

void test_pmm_initialization() {
    printf("Running PMM initialization test...\n");
    pmm_init(10);  // 初始化 PMM，假设有 10 个物理帧
    printf("PMM initialization test passed.\n");
}

void test_pmm_allocate_frame() {
    printf("Running PMM allocate frame test...\n");
    void *frame1 = pmm_allocate_frame();
    assert(frame1 != NULL);
    printf("Allocated frame at %p\n", frame1);

    void *frame2 = pmm_allocate_frame();
    assert(frame2 != NULL);
    printf("Allocated another frame at %p\n", frame2);

    printf("PMM allocate frame test passed.\n");
}

void test_pmm_free_frame() {
    printf("Running PMM free frame test...\n");
    void *frame = pmm_allocate_frame();
    assert(frame != NULL);
    printf("Allocated frame at %p\n", frame);

    pmm_free_frame(frame);
    printf("Freed frame at %p\n", frame);

    // Try allocating again to check if freed memory is reusable
    void *new_frame = pmm_allocate_frame();
    assert(new_frame != NULL);
    printf("Re-allocated frame at %p\n", new_frame);

    printf("PMM free frame test passed.\n");
}

void test_pmm_edge_cases() {
    printf("Running PMM edge cases test...\n");
    // Allocate all frames until full
    while (pmm_allocate_frame() != NULL);
    printf("Allocated all available physical frames.\n");

    // Try to allocate one more frame and expect NULL
    void *extra_frame = pmm_allocate_frame();
    assert(extra_frame == NULL);
    printf("No more frames available, allocation returned NULL as expected.\n");

    printf("PMM edge cases test passed.\n");
}

int main() {
    test_pmm_initialization();
    test_pmm_allocate_frame();
    test_pmm_free_frame();
    test_pmm_edge_cases();
    printf("All PMM tests passed successfully.\n");
    return 0;
}
