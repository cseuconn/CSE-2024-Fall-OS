#include "kernel/heap.h"
#include <stdio.h>
#include <assert.h>

void test_heap_initialization() {
    printf("Running heap initialization test...\n");
    heap_init(1024 * 1024); // Initialize with 1 MB of heap memory
    printf("Heap initialization test passed.\n");
}

void test_heap_allocation() {
    printf("Running heap allocation test...\n");
    void *block1 = heap_allocate(256);
    assert(block1 != NULL);
    printf("Allocated block1 at %p\n", block1);

    void *block2 = heap_allocate(512);
    assert(block2 != NULL);
    printf("Allocated block2 at %p\n", block2);

    printf("Heap allocation test passed.\n");
}

void test_heap_free() {
    printf("Running heap free test...\n");
    void *block = heap_allocate(128);
    assert(block != NULL);
    printf("Allocated block at %p\n", block);

    heap_free(block);
    printf("Freed block at %p\n", block);

    // Trying to allocate again to see if the memory is reusable
    void *block2 = heap_allocate(128);
    assert(block2 != NULL);
    printf("Re-allocated block at %p\n", block2);

    printf("Heap free test passed.\n");
}

void test_heap_edge_cases() {
    printf("Running heap edge cases test...\n");
    // Allocate a block of zero size
    void *block = heap_allocate(0);
    assert(block == NULL);
    printf("Allocation of zero size returned NULL as expected.\n");

    // Allocate a very large block exceeding heap size
    block = heap_allocate(1024 * 1024 * 2); // Request 2 MB from a 1 MB heap
    assert(block == NULL);
    printf("Allocation of block exceeding heap size returned NULL as expected.\n");

    printf("Heap edge cases test passed.\n");
}

int main() {
    test_heap_initialization();
    test_heap_allocation();
    test_heap_free();
    test_heap_edge_cases();
    printf("All heap tests passed successfully.\n");
    return 0;
}
