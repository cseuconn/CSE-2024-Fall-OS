#include "kernel/vmm.h"
#include "kernel/pmm.h"
#include "kernel/paging.h"
#include "kernel/heap.h"
#include <stdio.h>
#include <assert.h>

void test_pmm() {
    printf("Running PMM tests...\n");

    pmm_init(10);
    printf("PMM initialized.\n");

    void *frame1 = pmm_allocate_frame();
    assert(frame1 != NULL);
    printf("Allocated frame at %p\n", frame1);

    void *frame2 = pmm_allocate_frame();
    assert(frame2 != NULL);
    printf("Allocated another frame at %p\n", frame2);

    // Free and reallocate
    pmm_free_frame(frame1);
    printf("Freed frame at %p\n", frame1);

    void *frame3 = pmm_allocate_frame();
    assert(frame3 != NULL);
    printf("Re-allocated frame at %p\n", frame3);

    printf("PMM tests passed successfully.\n");
}

void test_vmm() {
    printf("Running VMM tests...\n");

    vmm_init();
    printf("VMM initialized.\n");

    void *page1 = vmm_allocate_page();
    assert(page1 != NULL);
    printf("Allocated page at %p\n", page1);

    void *page2 = vmm_allocate_page();
    assert(page2 != NULL);
    printf("Allocated another page at %p\n", page2);

    vmm_free_page(page1);
    printf("Freed page at %p\n", page1);

    void *new_page = vmm_allocate_page();
    assert(new_page != NULL);
    printf("Re-allocated page at %p\n", new_page);

    void *physical_address = vmm_translate(page2);
    assert(physical_address != NULL);
    printf("Translated virtual address %p to physical address %p\n", page2, physical_address);

    printf("VMM tests passed successfully.\n");
}

void test_paging() {
    printf("Running Paging tests...\n");

    paging_init(10);
    printf("Paging initialized with 10 entries.\n");

    void *virtual_address = (void *)0x1000;
    void *physical_address = (void *)0x2000;

    add_page_table_entry(virtual_address, physical_address);
    printf("Added page table entry: VA %p -> PA %p\n", virtual_address, physical_address);

    void *translated_address = get_physical_address(virtual_address);
    assert(translated_address == physical_address);
    printf("Translated virtual address %p to physical address %p\n", virtual_address, translated_address);

    remove_page_table_entry(virtual_address);
    printf("Removed page table entry for VA %p\n", virtual_address);

    translated_address = get_physical_address(virtual_address);
    assert(translated_address == NULL);
    printf("Translation for removed entry returned NULL as expected.\n");

    printf("Paging tests passed successfully.\n");
}

void test_heap() {
    printf("Running Heap tests...\n");

    heap_init(1024 * 1024); // 1 MB heap
    printf("Heap initialized with 1 MB.\n");

    void *block1 = heap_allocate(256);
    assert(block1 != NULL);
    printf("Allocated 256 bytes at %p\n", block1);

    void *block2 = heap_allocate(512);
    assert(block2 != NULL);
    printf("Allocated 512 bytes at %p\n", block2);

    heap_free(block1);
    printf("Freed 256 bytes at %p\n", block1);

    void *block3 = heap_allocate(128);
    assert(block3 != NULL);
    printf("Allocated 128 bytes at %p\n", block3);

    printf("Heap tests passed successfully.\n");
}

int main() {
    test_pmm();
    test_vmm();
    test_paging();
    test_heap();
    printf("All memory management tests passed successfully.\n");
    return 0;
}
