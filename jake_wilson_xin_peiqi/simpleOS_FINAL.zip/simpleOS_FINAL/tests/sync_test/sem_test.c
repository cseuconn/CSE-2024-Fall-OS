#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <assert.h>
#include <pthread.h>
#include "kernel/process.h"
#include "kernel/semaphore.h"

void test_semaphore_create() 
{
    printf("\nRunning test_semaphore_create()...\n");
    semaphore_t *sem = semaphore_create(5);
    assert(sem != NULL);
    printf("[OK] Semaphore created successfully\n");
    
    assert(sem->value == 5);
    printf("[OK] Initial value is 5\n");
    
    semaphore_destroy(sem);
    printf("[OK] Semaphore destroyed successfully\n");
}

void test_semaphore_wait_decrement() 
{
    printf("\nRunning test_semaphore_wait_decrement()...\n");
    semaphore_t *sem = semaphore_create(1);
    assert(sem != NULL);
    printf("[OK] Semaphore created with initial value 1\n");

    printf("Attempting semaphore wait...\n");
    int result = semaphore_wait(sem);
    assert(result == 0);
    printf("[OK] Wait operation succeeded\n");
    
    assert(sem->value == 0);
    printf("[OK] Value decremented to 0\n");

    semaphore_destroy(sem);
    printf("[OK] Semaphore destroyed successfully\n");
}

void *wait_thread(void *arg) {
    semaphore_t *sem = (semaphore_t *)arg;
    printf("Thread %llu waiting on semaphore...\n", (unsigned long long)pthread_self());
    semaphore_wait(sem);
    printf("Thread %llu acquired semaphore!\n", (unsigned long long)pthread_self());
    sleep(1);  // Simulate some work
    printf("Thread %llu releasing semaphore\n", (unsigned long long)pthread_self());
    semaphore_signal(sem);
    return NULL;
}

void test_semaphore_blocking() {
    printf("\nRunning test_semaphore_blocking()...\n");
    semaphore_t *sem = semaphore_create(2);  // Allow 2 concurrent threads
    pthread_t threads[4];  // Create 4 threads to test blocking
    
    printf("Creating 4 threads to test blocking behavior...\n");
    for(int i = 0; i < 4; i++) {
        pthread_create(&threads[i], NULL, wait_thread, sem);
        printf("Created thread %d\n", i + 1);
        usleep(100000);  // Small delay between thread creation
    }
    
    // Wait for all threads to complete
    for(int i = 0; i < 4; i++) {
        pthread_join(threads[i], NULL);
    }
    
    printf("All threads completed successfully\n");
    semaphore_destroy(sem);
    printf("[OK] Semaphore destroyed successfully\n");
}

void test_semaphore_signal() {
    printf("\nRunning test_semaphore_signal()...\n");
    semaphore_t *sem = semaphore_create(0);
    printf("Created semaphore with initial value 0\n");
    
    printf("Signaling semaphore...\n");
    assert(semaphore_signal(sem) == 0);
    printf("[OK] Signal operation succeeded\n");
    
    assert(sem->value == 1);
    printf("[OK] Value incremented to 1\n");
    
    semaphore_destroy(sem);
    printf("[OK] Semaphore destroyed successfully\n");
}

int main() {
    printf("Starting semaphore tests...\n");
    
    test_semaphore_create();
    test_semaphore_wait_decrement();
    test_semaphore_signal();
    test_semaphore_blocking();
    
    print_semaphore_stats();
    printf("\nAll semaphore tests completed successfully!\n");
    return 0;
}