#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <assert.h>
#include <pthread.h>
#include "kernel/process.h"
#include "kernel/mutex.h"

void test_mutex_create() 
{
    printf("\nRunning test_mutex_create()...\n");
    mutex_t *mutex = mutex_create();
    assert(mutex != NULL);
    printf("[OK] Mutex created successfully\n");
    
    assert(mutex->locked == false);
    printf("[OK] Initial locked state is false\n");
    
    assert(mutex->owner == NULL);
    printf("[OK] Initial owner is NULL\n");
    
    assert(mutex->wait_count == 0);
    printf("[OK] Initial wait count is 0\n");
    
    mutex_destroy(mutex);
    printf("[OK] Mutex destroyed successfully\n");
}

// Shared resource for testing
int shared_counter = 0;

void *increment_counter(void *arg) {
    mutex_t *mutex = (mutex_t *)arg;
    
    printf("Thread %llu attempting to lock mutex...\n", (unsigned long long)pthread_self());
    mutex_lock(mutex);
    printf("Thread %llu acquired lock\n", (unsigned long long)pthread_self());
    
    // Simulate some work
    shared_counter++;
    printf("Thread %llu incremented counter to %d\n", (unsigned long long)pthread_self(), shared_counter);
    sleep(1);
    
    printf("Thread %llu releasing lock\n", (unsigned long long)pthread_self());
    mutex_unlock(mutex);
    return NULL;
}

void test_mutex_concurrent_access() 
{
    printf("\nRunning test_mutex_concurrent_access()...\n");
    mutex_t *mutex = mutex_create();
    pthread_t threads[3];
    shared_counter = 0;
    
    printf("Creating 3 threads to increment shared counter...\n");
    for(int i = 0; i < 3; i++) {
        pthread_create(&threads[i], NULL, increment_counter, mutex);
    }
    
    // Wait for all threads to complete
    for(int i = 0; i < 3; i++) {
        pthread_join(threads[i], NULL);
    }
    
    printf("All threads completed. Final counter value: %d\n", shared_counter);
    assert(shared_counter == 3);
    printf("[OK] Counter value is correct\n");
    
    mutex_destroy(mutex);
    printf("[OK] Mutex destroyed successfully\n");
}

void test_mutex_lock_unlock() 
{
    printf("\nRunning test_mutex_lock_unlock()...\n");
    mutex_t *mutex = mutex_create();
    assert(mutex != NULL);
    printf("[OK] Mutex created successfully\n");

    printf("Attempting to lock mutex...\n");
    assert(mutex_lock(mutex) == 0);
    printf("[OK] Mutex locked successfully\n");
    assert(mutex->locked == true);
    printf("[OK] Locked state verified\n");

    printf("Attempting to unlock mutex...\n");
    assert(mutex_unlock(mutex) == 0);
    printf("[OK] Mutex unlocked successfully\n");
    assert(mutex->locked == false);
    printf("[OK] Unlocked state verified\n");

    mutex_destroy(mutex);
    printf("[OK] Mutex destroyed successfully\n");
}

int main()
{
    printf("Starting mutex tests...\n");
    
    test_mutex_create();
    test_mutex_lock_unlock();
    test_mutex_concurrent_access();
    
    print_mutex_stats();
    printf("\nAll mutex tests completed successfully!\n");
    return 0;
}