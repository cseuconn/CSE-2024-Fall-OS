#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "kernel/scheduler.h"
#include "kernel/process.h"

#define MIN_PROCESSES 3
#define MIN_PRIORITY 1
#define MAX_PRIORITY 10

// Generate random processes
int generate_test_processes(pcb_t* processes) {
    int num_processes = (rand() % (MAX_PROCESSES - MIN_PROCESSES + 1)) + MIN_PROCESSES;
    
    printf("\nGenerating %d random processes:\n", num_processes);
    for (int i = 0; i < num_processes; i++) {
        processes[i].pid = i + 1;
        processes[i].priority = (rand() % (MAX_PRIORITY - MIN_PRIORITY + 1)) + MIN_PRIORITY;
        processes[i].state = READY;
        processes[i].next = (i < num_processes - 1) ? &processes[i + 1] : NULL;
        printf("Created Process %d (Priority: %d)\n", processes[i].pid, processes[i].priority);
    }
    return num_processes;
}

// Test FCFS scheduling
void test_fcfs(pcb_t* base_processes, int num_processes) {
    printf("\n=== Testing FCFS Scheduling ===\n");
    set_scheduling_algorithm(SCHED_TYPE_FCFS);
    
    // Create a copy of processes
    pcb_t* processes = malloc(sizeof(pcb_t) * num_processes);
    memcpy(processes, base_processes, sizeof(pcb_t) * num_processes);
    
    for (int i = 0; i < num_processes; i++) {
        // Run current process until completion
        int executions = (rand() % 3) + 2; // Random number of executions (2-4)
        for (int j = 0; j < executions; j++) {
            printf("[FCFS] Running PID %d\n", processes[i].pid);
        }
        printf("[FCFS] Process %d completed\n", processes[i].pid);
    }
    
    free(processes);
}

// Test Round Robin scheduling
void test_round_robin(pcb_t* base_processes, int num_processes) {
    printf("\n=== Testing Round Robin Scheduling ===\n");
    set_scheduling_algorithm(SCHED_TYPE_RR);
    
    int quantum = (rand() % 81) + 20;  // Random quantum between 20-100ms
    set_time_quantum(quantum);
    printf("Time Quantum set to: %dms\n", quantum);
    
    // Create a copy of processes and track their completion
    pcb_t* processes = malloc(sizeof(pcb_t) * num_processes);
    memcpy(processes, base_processes, sizeof(pcb_t) * num_processes);
    int* completed = calloc(num_processes, sizeof(int));
    int remaining = num_processes;
    
    while (remaining > 0) {
        for (int i = 0; i < num_processes; i++) {
            if (!completed[i]) {
                printf("[RR] Running PID %d\n", processes[i].pid);
                
                if (rand() % 4 == 0) {  // 25% chance to complete
                    printf("[RR] Process %d completed\n", processes[i].pid);
                    completed[i] = 1;
                    remaining--;
                }
            }
        }
    }
    
    free(processes);
    free(completed);
}

// Test Priority scheduling
void test_priority(pcb_t* base_processes, int num_processes) {
    printf("\n=== Testing Priority Scheduling ===\n");
    set_scheduling_algorithm(SCHED_TYPE_PRIORITY);
    
    // Create a copy of processes
    pcb_t* processes = malloc(sizeof(pcb_t) * num_processes);
    memcpy(processes, base_processes, sizeof(pcb_t) * num_processes);
    int* completed = calloc(num_processes, sizeof(int));
    int remaining = num_processes;
    
    while (remaining > 0) {
        // Find highest priority non-completed process
        int highest_priority = MAX_PRIORITY + 1;
        int selected_idx = -1;
        
        for (int i = 0; i < num_processes; i++) {
            if (!completed[i] && processes[i].priority < highest_priority) {
                highest_priority = processes[i].priority;
                selected_idx = i;
            }
        }
        
        if (selected_idx >= 0) {
            printf("[Priority] Running PID %d (Priority %d)\n", 
                   processes[selected_idx].pid, processes[selected_idx].priority);
            
            // Random priority adjustment (10% chance)
            if (rand() % 10 == 0 && processes[selected_idx].priority > MIN_PRIORITY) {
                processes[selected_idx].priority--;
                printf("[Priority] PID %d priority boosted to %d\n", 
                       processes[selected_idx].pid, processes[selected_idx].priority);
            }
            
            if (rand() % 3 == 0) {  // 33% chance to complete
                printf("[Priority] Process %d completed\n", processes[selected_idx].pid);
                completed[selected_idx] = 1;
                remaining--;
            }
        }
    }
    
    free(processes);
    free(completed);
}

int main() {
    srand(time(NULL));
    scheduler_init();
    
    // Generate random test processes
    pcb_t* base_processes = malloc(sizeof(pcb_t) * MAX_PROCESSES);
    int num_processes = generate_test_processes(base_processes);
    
    // Run tests
    test_fcfs(base_processes, num_processes);
    test_round_robin(base_processes, num_processes);
    test_priority(base_processes, num_processes);
    
    // Cleanup
    free(base_processes);
    
    printf("\nAll scheduler tests completed!\n");
    return 0;
}