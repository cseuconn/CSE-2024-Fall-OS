#include <stdio.h>
#include <assert.h>
#include <unistd.h>
#include <stdbool.h>
#include "kernel/process.h"

// Track process completion
static bool process1_done = false;
static bool process2_done = false;
static bool process3_done = false;

void process1(void) {
    printf("[P1] Process 1 starting\n");
    process_yield();
    printf("[P1] Process 1 resuming after yield\n");
    process_yield();
    printf("[P1] Process 1 finishing\n");
    process1_done = true;
}

void process2(void) {
    printf("[P2] Process 2 starting\n");
    process_yield();
    printf("[P2] Process 2 resuming after yield\n");
    printf("[P2] Process 2 finishing\n");
    process2_done = true;
}

void process3(void) {
    printf("[P3] Process 3 starting\n");
    process_yield();
    printf("[P3] Process 3 finishing\n");
    process3_done = true;
}

void verify_ready_queue(void) {
    pcb_t* ready = get_ready_queue();
    printf("\nVerifying ready queue state:\n");
    while (ready) {
        printf("Process %d (state: %d) -> ", ready->pid, ready->state);
        ready = ready->next;
    }
    printf("END\n\n");
}

int main(void) {
    printf("Starting process management test...\n\n");

    // Initialize process management
    assert(process_init() == 0);
    
    // Create test processes
    int pid1 = process_create(process1);
    int pid2 = process_create(process2);
    int pid3 = process_create(process3);
    
    // Verify process creation
    assert(pid1 > 0);
    assert(pid2 > 0);
    assert(pid3 > 0);
    
    // Give processes time to execute and verify queue state periodically
    for (int i = 0; i < 4; i++) {
        verify_ready_queue();
        usleep(500000); // Sleep for 500ms between checks
    }
    
    // Verify all processes completed
    assert(process1_done && "Process 1 did not complete");
    assert(process2_done && "Process 2 did not complete");
    assert(process3_done && "Process 3 did not complete");
    
    // Print statistics
    process_print_stats();
    
    // Clean up
    process_cleanup();
    
    printf("\nTest completed successfully!\n");
    return 0;
}