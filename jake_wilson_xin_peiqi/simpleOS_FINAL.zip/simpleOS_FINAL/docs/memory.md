# Memory Management Documentation

## Overview

The memory management part of SimpleOS is in charge of handling **virtual memory** and **physical memory**. It makes sure that the kernel can use memory efficiently and without problems. This includes allocating memory, managing pages, and translating addresses between virtual and physical spaces.

The main parts of this system are:

- **Virtual Memory Manager (VMM)**: Manages the virtual memory, including allocation and address translation.
- **Physical Memory Manager (PMM)**: Manages physical memory frames, making sure that virtual pages have actual memory to use.
- **Paging System**: Maps virtual addresses to physical addresses so that memory is used effectively.

## Key Components

### Virtual Memory Manager (VMM)

The VMM manages the virtual memory for SimpleOS. It handles the setup, allocation, freeing, and translating of virtual pages.

#### Functions

- **`vmm_init()`**: Sets up the virtual memory manager, including the memory space and the page bitmap.
- **`vmm_allocate_page()`**: Allocates a virtual page and returns the address for that page.
- **`vmm_free_page(void *virtual_address)`**: Frees the memory for the given virtual page.
- **`vmm_translate(void *virtual_address)`**: Converts a virtual address to a physical address.

### Physical Memory Manager (PMM)

The PMM manages physical memory frames. It works with the VMM to ensure each virtual page is mapped to real physical memory.

#### Functions

- **`pmm_allocate_frame()`**: Allocates a frame of physical memory for a virtual page.
- **`pmm_free_frame(void *frame_address)`**: Frees a physical memory frame that was previously allocated.

### Paging System

The paging system is responsible for mapping virtual addresses to physical addresses using page tables.

#### Functions

- **`paging_init(size_t total_pages)`**: Initializes the paging system with the number of pages available.
- **`add_page_table_entry(void *virtual_address, void *physical_address)`**: Adds an entry in the page table that links a virtual address to a physical address.
- **`remove_page_table_entry(void *virtual_address)`**: Removes the mapping for a virtual address.
- **`get_physical_address(void *virtual_address)`**: Finds the physical address that matches a given virtual address.

## Core API Functions

### Initialization

```c
void vmm_init();
```

This function sets up the virtual memory manager. It allocates memory for the virtual space and prepares a bitmap to track which pages are used or free.

### Page Allocation

```c
void *vmm_allocate_page();
```

Allocates a new page of virtual memory. This function finds the first free page, marks it as used, and then updates the page table to link it to a physical frame.

### Page Deallocation

```c
void vmm_free_page(void *virtual_address);
```

Frees a virtual page that was allocated earlier. It releases the physical frame, updates the bitmap, and removes the page table entry.

### Address Translation

```c
void *vmm_translate(void *virtual_address);
```

Translates a virtual address to a physical address by looking it up in the page table.

## Implementation Details

### Memory Space Initialization

- **Virtual Memory Space**: This is a block of memory used to represent the virtual address space of SimpleOS. The system uses a bitmap to keep track of which pages are used or free.
- **Page Bitmap**: The bitmap helps track the status of each page. If a page is used, the bit is set; if it is free, the bit is clear.

### Page Allocation Flow

1. **Find Free Page**: Look through the bitmap to find the first free page.
2. **Allocate Physical Frame**: Use `pmm_allocate_frame()` to get a physical memory frame.
3. **Update Page Table**: Add a new entry in the page table to link the virtual page to the physical frame.
4. **Return Address**: Return the address of the allocated virtual page to the caller.

### Page Deallocation Flow

1. **Check Validity**: Make sure the virtual address is valid and currently allocated.
2. **Update Bitmap**: Mark the page as free in the bitmap.
3. **Release Physical Frame**: Call `pmm_free_frame()` to release the physical frame.
4. **Remove Page Table Entry**: Remove the mapping for the virtual address in the page table.

### Address Translation Flow

To convert a virtual address to a physical address, the system checks the page table to find which physical frame the virtual address maps to.

### Synchronization Considerations

This version does not have locks for multi-threading. In a system with multiple threads, you would need to add locks to prevent data corruption when updating shared data structures like the page table or bitmap.

## Limitations

- **Fixed Virtual Memory Size**: The virtual memory size is fixed at **128 MB**.
- **No Dynamic Memory Expansion**: The virtual memory pool cannot grow beyond its initial size.
- **Not Thread Safe**: This implementation is not safe for use with multiple threads at the same time.
- **Simple Allocation Strategy**: Uses a first-fit strategy, which can lead to fragmentation over time.

## Example Usage

```c
// Set up the virtual memory manager
vmm_init();

// Allocate a virtual page
void *page = vmm_allocate_page();
if (page != NULL) {
    printf("Allocated virtual page at %p\n", page);
}

// Translate a virtual address to a physical address
void *physical = vmm_translate(page);
if (physical != NULL) {
    printf("Translated to physical address %p\n", physical);
}

// Free the allocated page
vmm_free_page(page);
```

## Testing

The tests (`alloc_test.c` and `page_test.c`) check several things:

- **Page Allocation and Deallocation**: Makes sure pages can be allocated and freed correctly.
- **Address Translation**: Checks if virtual addresses translate to the correct physical addresses.
- **Error Handling**: Tests if invalid addresses are handled properly.

To run the tests, use:

```bash
make test
```

## Future Improvements

1. **Thread Safety**: Add locks to make the memory management functions safe for multi-threading.
2. **Dynamic Memory**: Allow the virtual memory space to grow as needed.
3. **Better Allocation Strategies**: Use algorithms like **best-fit** or **buddy system** to improve memory allocation.
4. **Page Swapping**: Add swapping to move unused pages to disk to free up physical memory for other processes.
