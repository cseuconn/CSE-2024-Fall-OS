# Process Management Documentation

## Overview
The process management subsystem implements basic process creation, scheduling, and control mechanisms for SimpleOS. It provides a multi-threaded environment where processes can be created, scheduled, and terminated according to different scheduling policies.

## Key Components

### Process Control Block (PCB)
typedef struct pcb {
    int pid;                // Process ID
    process_state_t state;  // Current state
    pthread_t thread;       // Actual thread running the process
    void (*entry)(void);    // Entry point function
    struct pcb* next;       // For ready queue
    int priority;           // Process priority
    int time_quantum;       // Time quantum for RR
} pcb_t;

### Process States
Processes can be in one of the following states:
- `READY`: Process is ready to execute but waiting for CPU
- `RUNNING`: Process is currently executing
- `WAITING`: Process is blocked waiting for an event
- `TERMINATED`: Process has completed execution

### Priority Levels
The system supports four priority levels:
- `PRIORITY_HIGH (0)`: Highest priority
- `PRIORITY_NORMAL (1)`: Normal priority
- `PRIORITY_LOW (2)`: Low priority
- `PRIORITY_IDLE (3)`: Lowest priority

## Core API Functions

### Initialization
int process_init(void)
Initializes the process management subsystem. Must be called before any other process operations.

### Process Creation
int process_create(void (*entry)(void))
Creates a new process with the specified entry function. Returns the process ID (pid) on success, -1 on failure.

### Process Control
void process_yield(void)      // Voluntarily give up CPU
pcb_t* process_get_current()  // Get current running process
void process_cleanup(void)    // Clean up all processes

### Statistics and Debugging
void process_print_stats(void)  // Print process statistics


## Scheduler Integration
The process management system works closely with the scheduler to implement different scheduling policies:

### Supported Scheduling Algorithms
- Round Robin (RR): Time-sliced scheduling with configurable quantum
- First-Come-First-Served (FCFS): Simple non-preemptive scheduling
- Priority-based: Scheduling based on process priority levels

### Scheduling Configuration
void set_scheduling_algorithm(sched_type_t type)  // Change scheduling algorithm
void set_time_quantum(int quantum_ms)            // Set RR time quantum

## Implementation Details

### Process Creation Flow
1. Allocate and initialize new PCB
2. Assign unique PID
3. Set initial state to READY
4. Add to ready queue
5. Create underlying thread
6. Update statistics

### Context Switching
Context switches can occur in two ways:
1. Voluntary: Process calls `process_yield()`
2. Involuntary: Scheduler preempts running process

### Synchronization
- Uses mutex lock (`scheduler_lock`) to protect shared data structures
- Condition variable (`scheduler_cond`) for process state changes
- All queue modifications happen under lock protection

## Statistics Tracking
The system maintains various statistics:
- Total number of processes
- Per-process statistics:
  - Context switches
  - Voluntary yields
  - Runtime units

## Limitations
- Maximum number of processes limited by `MAX_PROCESSES` (currently 5)
- Fixed priority levels
- No support for process hierarchies or parent-child relationships
- No inter-process communication mechanisms

## Error Handling
- Process creation fails if:
  - Memory allocation fails
  - Thread creation fails
  - Maximum process limit reached
- Returns -1 on errors, positive PID on success

## Example Usage

// Initialize process management
process_init();

// Create a new process
int pid = process_create(process_entry_function);
if (pid < 0) {
    // Handle error
}

// Current process voluntarily yields CPU
process_yield();

// Get statistics
process_print_stats();

// Clean up
process_cleanup();

## Testing
The included test suite (`scheduler_test.c`) provides comprehensive testing of:
- Process creation and termination
- Different scheduling algorithms
- Priority handling
- Context switching
- Statistics tracking

## Future Improvements
Potential areas for enhancement:
1. Support for process hierarchies
2. Inter-process communication mechanisms
3. Dynamic priority adjustment
4. More sophisticated scheduling algorithms
5. Process groups and job control
6. Resource usage limits and accounting