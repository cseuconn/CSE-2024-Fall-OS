# File System Documentation

## Overview
The file system implementation provides a basic file management system for SimpleOS. It supports file and directory operations, such as creating, opening, reading, writing, and deleting files and directories. The file system integrates with the underlying buffer cache and inode management subsystems to provide persistent storage.

## Key Components

### File Descriptor Management
The file system maintains a table of open file descriptors, each representing an active file or directory. The `fs_state.open_files` array stores information about the open files, including the associated inode number, file access flags, and whether the file is currently open.

### Path Management
The file system uses a path table (`fs_state.paths`) to keep track of the files and directories in the file system. Each entry in the path table includes the path name, inode number, file type (regular file or directory), and deletion status.

### Inode Management
The file system integrates with the inode management subsystem to handle file and directory metadata, such as file size, block pointers, and access times. The `inode_t` structure represents an individual inode.

### Buffer Cache Integration
The file system relies on the buffer cache subsystem to read and write data blocks for files. The `buffer_get()`, `buffer_read()`, `buffer_write()`, and `buffer_release()` functions are used to interact with the buffer cache.

## Core API Functions

### Initialization and Cleanup
`int fs_init(void)`: Initializes the file system by setting up the necessary subsystems (inode, buffer cache, file management).
`void fs_cleanup(void)`: Cleans up the file system, closing all open files and releasing associated resources.

### File and Directory Operations
`int fs_create(const char* path, file_type_t type)`: Creates a new file or directory at the specified path.
`int fs_open(const char* path, int flags)`: Opens a file at the specified path with the given access flags.
`int fs_close(int fd)`: Closes the file associated with the given file descriptor.
`ssize_t fs_read(int fd, void* buf, size_t count)`: Reads data from the file associated with the given file descriptor.
`ssize_t fs_write(int fd, const void* buf, size_t count)`: Writes data to the file associated with the given file descriptor.
`int fs_unlink(const char* path)`: Deletes the file at the specified path.
`int fs_mkdir(const char* path)`: Creates a new directory at the specified path.
`int fs_rmdir(const char* path)`: Removes the directory at the specified path.
`int fs_readdir(int fd, dir_entry_t* entry)`: Reads the next directory entry from the directory associated with the given file descriptor.
`int fs_seek(int fd, off_t offset, int whence)`: Sets the file position indicator associated with the given file descriptor.
`off_t fs_tell(int fd)`: Returns the current value of the file position indicator of the file associated with the given file descriptor.

### Statistics
`struct fs_stats* fs_get_stats(void)`: Returns a pointer to the file system statistics structure.
`void fs_print_stats(void)`: Prints the file system statistics.

## Implementation Details

### File Descriptor Allocation
When a file is opened using `fs_open()`, the file system allocates a free file descriptor from the `fs_state.open_files` array and initializes the necessary information, such as the inode number and access flags.

### Path Management
The `find_path()`, `add_path()`, and `remove_path()` functions are used to manage the path table (`fs_state.paths`). The path table keeps track of the files and directories in the file system, including their inode numbers, types, and deletion status.

### File and Directory Operations
The file system operations, such as `fs_read()`, `fs_write()`, and `fs_readdir()`, interact with the underlying buffer cache and inode management subsystems to perform the requested actions.

### Error Handling
The file system API functions return -1 on error and set the appropriate errno value. Common error conditions include invalid parameters, non-existent paths, and resource exhaustion (e.g., no free file descriptors).

## Integration with Other Subsystems

### Buffer Cache
The file system relies on the buffer cache subsystem to read and write data blocks. The `buffer_get()`, `buffer_read()`, `buffer_write()`, and `buffer_release()` functions are used to interact with the buffer cache.

### Inode Management
The file system integrates with the inode management subsystem to handle file and directory metadata, such as file size, block pointers, and access times. The `inode_allocate()`, `inode_free()`, `inode_get_block()`, `inode_add_block()`, `inode_get_size()`, and `inode_update_size()` functions are used to manage inodes.

### Process Management
The file system does not directly interact with the process management subsystem, but the two subsystems work together to provide a complete file system functionality for SimpleOS.

## Example Usage

Here's an example of how to use the file system API:

In C language:

// Initialize the file system
assert(fs_init() == 0);

// Create a new file
assert(fs_create("/example.txt", FILE_TYPE_REGULAR) == 0);

// Open the file for writing
int fd = fs_open("/example.txt", O_WRITE);
assert(fd >= 0);

// Write some data to the file
const char* data = "Hello, world!";
ssize_t bytes_written = fs_write(fd, data, strlen(data));
assert(bytes_written == strlen(data));

// Seek to the beginning of the file
assert(fs_seek(fd, 0, SEEK_SET) == 0);

// Read the data back from the file
char buffer[64] = {0};
ssize_t bytes_read = fs_read(fd, buffer, sizeof(buffer));
assert(bytes_read == strlen(data));
assert(strcmp(buffer, data) == 0);

// Close the file
assert(fs_close(fd) == 0);

// Delete the file
assert(fs_unlink("/example.txt") == 0);

// Clean up the file system
fs_cleanup();

## Limitations and Future Improvements

### Limitations
- Limited number of open files and paths due to fixed-size arrays
- No support for symbolic links or hard links
- No support for extended file attributes or metadata
- No support for file permissions or access control

### Future Improvements
1. Dynamic allocation of file descriptors and path table entries
2. Support for symbolic links and hard links
3. Extended file attributes and metadata
4. File permissions and access control
5. Journaling or transaction-based file system for improved reliability
6. Support for more advanced file system features, such as directories with large numbers of files, file fragmentation management, and caching optimizations

## Testing
The file system implementation includes a comprehensive test suite (`file_test.c`) that covers the following aspects:
- Buffer cache operations
- Inode management
- File and directory creation, deletion, and access
- Error handling

The test suite ensures the correctness of the file system API and the integration with the underlying subsystems.