#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <time.h>
#include <sys/time.h>
#include <string.h>
#include "kernel/process.h"
#include "kernel/scheduler.h"

// Global variables
static pcb_t* ready_queue = NULL;
static pcb_t* current_process = NULL;
static int next_pid = 0;
static pthread_mutex_t scheduler_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t scheduler_cond = PTHREAD_COND_INITIALIZER;

// Getter functions for testing purposes
pthread_mutex_t* get_scheduler_lock(void) {
    return &scheduler_lock;
}

pcb_t* get_ready_queue(void) {
    return ready_queue;
}

pcb_t* get_current_process(void) {
    return current_process;
}


// Statistics tracking
static struct {
    int total_processes;
    struct {
        int switches;
        int yields;
        int runtime;
    } per_process[MAX_PROCESSES];
} stats = {0};

static void update_process_stats(int pid, int switches, int yields, int runtime) {
    if (pid > 0 && pid < MAX_PROCESSES) {
        stats.per_process[pid].switches += switches;
        stats.per_process[pid].yields += yields;
        stats.per_process[pid].runtime += runtime;
    }
}


// Process wrapper function
static void* process_wrapper(void* arg) {
    pcb_t* pcb = (pcb_t*)arg;
    struct timeval start, end;
    gettimeofday(&start, NULL);
    
    while (pcb->state != TERMINATED) {
        pthread_mutex_lock(&scheduler_lock);
        
        // Wait while process is not running
        while (pcb->state != RUNNING && pcb->state != TERMINATED) {
            pthread_cond_wait(&scheduler_cond, &scheduler_lock);
        }
        
        // Check if terminated after waking up
        if (pcb->state == TERMINATED) {
            pthread_mutex_unlock(&scheduler_lock);
            break;
        }
        
        pthread_mutex_unlock(&scheduler_lock);
        
        // Run the process' entry function
        pcb->entry();
        
        // Mark process as terminated after completion
        pthread_mutex_lock(&scheduler_lock);
        pcb->state = TERMINATED;
        
        // Calculate and update runtime
        gettimeofday(&end, NULL);
        unsigned long runtime = (end.tv_sec - start.tv_sec) * 1000 +
                              (end.tv_usec - start.tv_usec) / 1000;
        update_process_stats(pcb->pid, 0, 0, runtime / 100);
        
        // If this was the current process, clear it
        if (current_process == pcb) {
            current_process = NULL;
            
            // Get next process from ready queue
            if (ready_queue) {
                current_process = ready_queue;
                ready_queue = ready_queue->next;
                current_process->next = NULL;
                current_process->state = RUNNING;
            }
        }
        
        pthread_cond_broadcast(&scheduler_cond);
        pthread_mutex_unlock(&scheduler_lock);
        break;
    }
    
    return NULL;
}


static void print_ready_queue(void) {
    printf("\033[36m[Queue] Ready: ");
    pcb_t* temp = ready_queue;
    while (temp) {
        printf("P%d -> ", temp->pid);
        temp = temp->next;
    }
    printf("END\033[0m\n");
}

// Initialize process management
int process_init(void) {
    // First cleanup any existing state
    process_cleanup();
    
    // Initialize fresh state
    ready_queue = NULL;
    current_process = NULL;
    next_pid = 0;

    // Initialize synchronization primitives
    pthread_mutex_init(&scheduler_lock, NULL);
    pthread_cond_init(&scheduler_cond, NULL);
    
    // Clear statistics
    stats.total_processes = 0;
    memset(stats.per_process, 0, sizeof(stats.per_process));
    
    printf("\033[32m[System] Process management initialized\033[0m\n");
    return 0;
}

// Create a new process
int process_create(void (*entry)(void)) {
    pcb_t* pcb = (pcb_t*)malloc(sizeof(pcb_t));
    if (!pcb) return -1;
    
    // Initialize PCB
    pcb->pid = ++next_pid;
    pcb->state = READY;
    pcb->entry = entry;
    pcb->next = NULL;
    pcb->priority = PRIORITY_NORMAL;
    pcb->time_quantum = DEFAULT_TIME_QUANTUM;
    
    // Update statistics
    stats.total_processes++;
    
    // Add to ready queue
    pthread_mutex_lock(&scheduler_lock);
    
    // If no current process, make this the current process
    if (!current_process) {
        current_process = pcb;
        pcb->state = RUNNING;
    } else {
        // Add to end of ready queue
        if (!ready_queue) {
            ready_queue = pcb;
        } else {
            pcb_t* temp = ready_queue;
            while (temp->next) {
                temp = temp->next;
            }
            temp->next = pcb;
        }
    }
    
    printf("\033[32m[System] Created Process %d\033[0m\n", pcb->pid);
    print_ready_queue();
    pthread_mutex_unlock(&scheduler_lock);
    
    // Create actual thread
    if (pthread_create(&pcb->thread, NULL, process_wrapper, pcb) != 0) {
        free(pcb);
        return -1;
    }
    
    return pcb->pid;
}

// Process yields CPU
void process_yield(void) {
    pthread_mutex_lock(&scheduler_lock);
    
    if (current_process) {
        // Update statistics for yielding process
        int old_pid = current_process->pid;
        update_process_stats(old_pid, 0, 1, 1);
        
        if (ready_queue) {  // Only yield if there's another process to run
            // Move current process to ready queue
            current_process->state = READY;
            current_process->next = ready_queue;
            ready_queue = current_process;
            
            // Select next process
            pcb_t* next = ready_queue;
            ready_queue = ready_queue->next;
            next->next = NULL;
            
            // Update current process
            current_process = next;
            current_process->state = RUNNING;
        }
    }
    
    pthread_cond_broadcast(&scheduler_cond);
    pthread_mutex_unlock(&scheduler_lock);
}


// Get current process
pcb_t* process_get_current(void) {
    return current_process;
}

// Print process statistics
void process_print_stats(void) {
    printf("\n\033[35m=== Process Statistics ===\033[0m\n");
    printf("Total processes: %d\n", stats.total_processes);
    printf("\nPer-Process Statistics:\n");
    for (int i = 1; i <= next_pid; i++) {
        printf("Process %d:\n", i);
        printf("  - Yields: %d\n", stats.per_process[i].yields);
        printf("  - Runtime units: %d\n", stats.per_process[i].runtime);
    }
    printf("\033[35m========================\033[0m\n\n");
}

void process_cleanup(void) {
    pthread_mutex_lock(&scheduler_lock);

    // First mark all processes as terminated
    pcb_t *current = ready_queue;
    while (current) {
        current->state = TERMINATED;
        current = current->next;
    }

    // Signal any waiting processes
    pthread_cond_broadcast(&scheduler_cond);
    pthread_mutex_unlock(&scheduler_lock);

    // Give threads time to finish
    usleep(100000);

    pthread_mutex_lock(&scheduler_lock);

    // Clean up ready queue and join threads
    current = ready_queue;
    while (current) {
        pcb_t *next = current->next;
        pthread_join(current->thread, NULL);
        free(current);
        current = next;
    }

    // Reset all state
    ready_queue = NULL;
    current_process = NULL;
    next_pid = 0;

    // Reset stats
    stats.total_processes = 0;
    memset(stats.per_process, 0, sizeof(stats.per_process));

    pthread_mutex_unlock(&scheduler_lock);

    // Reinitialize synchronization primitives
    pthread_mutex_destroy(&scheduler_lock);
    pthread_cond_destroy(&scheduler_cond);
    pthread_mutex_init(&scheduler_lock, NULL);
    pthread_cond_init(&scheduler_cond, NULL);

    printf("\033[32m[System] Process state cleaned up completely\033[0m\n");
}
