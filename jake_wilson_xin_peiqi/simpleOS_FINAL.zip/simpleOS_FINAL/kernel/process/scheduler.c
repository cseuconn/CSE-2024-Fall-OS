#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include "kernel/scheduler.h"
#include "kernel/process.h"

// Current scheduling algorithm
static sched_type_t current_sched_type = SCHED_TYPE_RR;
static int time_quantum = DEFAULT_TIME_QUANTUM;

// Statistics for scheduler
static struct sched_stats {
    unsigned long total_switches;
    unsigned long total_waiting_time;
    double avg_turnaround_time;
    struct timeval start_time;
    struct {
        struct timeval start;
        unsigned long wait_time;
        unsigned long turnaround_time;
    } process_stats[MAX_PROCESSES];
} sched_stats;

// Forward declarations of scheduling functions
static pcb_t* schedule_round_robin(pcb_t* ready_queue);
static pcb_t* schedule_fcfs(pcb_t* ready_queue);
static pcb_t* schedule_priority(pcb_t* ready_queue);

// Main scheduling function
pcb_t* schedule_next_process(pcb_t* ready_queue) {
    if (!ready_queue) return NULL;

    switch (current_sched_type) {
        case SCHED_TYPE_RR:
            return schedule_round_robin(ready_queue);
        case SCHED_TYPE_FCFS:
            return schedule_fcfs(ready_queue);
        case SCHED_TYPE_PRIORITY:
            return schedule_priority(ready_queue);
        default:
            return schedule_round_robin(ready_queue);
    }
}

// Round Robin scheduling algorithm
static pcb_t* schedule_round_robin(pcb_t* ready_queue) {
    if (!ready_queue) return NULL;
    
    pcb_t* next = ready_queue;
    sched_stats.total_switches++;
    sched_stats.total_waiting_time += time_quantum;
    
    // Update average turnaround time with actual switch
    sched_stats.avg_turnaround_time = 
        (sched_stats.total_waiting_time) / sched_stats.total_switches;
    
    return next;
}

// First Come First Serve scheduling
static pcb_t* schedule_fcfs(pcb_t* ready_queue) {
    if (!ready_queue) return NULL;
    
    pcb_t* next = ready_queue;
    sched_stats.total_switches++;
    sched_stats.total_waiting_time += DEFAULT_TIME_QUANTUM;
    
    // Update average turnaround time
    sched_stats.avg_turnaround_time = 
        (sched_stats.avg_turnaround_time * (sched_stats.total_switches - 1) + 
         sched_stats.total_waiting_time) / sched_stats.total_switches;
    
    printf("\033[36m[Scheduler] FCFS: Selected PID %d\033[0m\n", next->pid);
    return next;
}

// Priority scheduling
static pcb_t* schedule_priority(pcb_t* ready_queue) {
    if (!ready_queue) return NULL;
    
    // Find highest priority process
    pcb_t* next = ready_queue;
    pcb_t* temp = ready_queue;
    int highest_priority = next->priority;
    
    while (temp) {
        if (temp->priority < highest_priority) {  // Lower number = higher priority
            highest_priority = temp->priority;
            next = temp;
        }
        temp = temp->next;
    }
    
    sched_stats.total_switches++;
    sched_stats.total_waiting_time += DEFAULT_TIME_QUANTUM;
    
    // Update average turnaround time
    sched_stats.avg_turnaround_time = 
        (sched_stats.avg_turnaround_time * (sched_stats.total_switches - 1) + 
         sched_stats.total_waiting_time) / sched_stats.total_switches;
    
    printf("\033[36m[Scheduler] Priority: Selected PID %d (priority %d)\033[0m\n", 
           next->pid, next->priority);
    return next;
}

// Initialize the scheduler
void scheduler_init(void) {
    current_sched_type = SCHED_TYPE_RR;
    time_quantum = DEFAULT_TIME_QUANTUM;
    // Initialize stats to 0
    sched_stats.total_switches = 0;
    sched_stats.total_waiting_time = 0;
    sched_stats.avg_turnaround_time = 0.0;
    
    printf("\033[32m[Scheduler] Initialized with Round Robin (quantum=%dms)\033[0m\n", 
           time_quantum);
}

// Change scheduling algorithm
void set_scheduling_algorithm(sched_type_t type) {
    current_sched_type = type;
    printf("\033[32m[Scheduler] Changed scheduling algorithm to %s\033[0m\n",
           type == SCHED_TYPE_RR ? "Round Robin" :
           type == SCHED_TYPE_FCFS ? "First Come First Serve" :
           "Priority Based");
}

// Set time quantum for Round Robin
void set_time_quantum(int quantum_ms) {
    if (quantum_ms >= MIN_TIME_QUANTUM && quantum_ms <= MAX_TIME_QUANTUM) {
        time_quantum = quantum_ms;
        printf("\033[32m[Scheduler] Set time quantum to %dms\033[0m\n", quantum_ms);
    }
}

// Print scheduler statistics
void print_scheduler_stats(void) {
    printf("\n\033[35m=== Scheduler Statistics ===\033[0m\n");
    // Print actual stats values instead of 0
    printf("Total waiting time: %lu ms\n", sched_stats.total_waiting_time);
    printf("Average turnaround time: %.2f ms\n", sched_stats.avg_turnaround_time);
    printf("Current scheduling algorithm: %s\n",
           current_sched_type == SCHED_TYPE_RR ? "Round Robin" :
           current_sched_type == SCHED_TYPE_FCFS ? "First Come First Serve" :
           "Priority Based");
    printf("Current time quantum: %d ms\n", time_quantum);
    printf("\033[35m===========================\033[0m\n\n");
}