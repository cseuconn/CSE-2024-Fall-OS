#include "kernel/pmm.h"
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>

#define PAGE_SIZE 4096

static size_t total_frames;
static bool *frame_bitmap = NULL;
static void *physical_memory_space = NULL;

void pmm_init(size_t total_frames_count) {
    total_frames = total_frames_count;

    frame_bitmap = calloc(total_frames, sizeof(bool));
    if (!frame_bitmap) {
        fprintf(stderr, "Failed to allocate frame bitmap.\n");
        exit(1);
    }

    physical_memory_space = malloc(total_frames * PAGE_SIZE);
    if (!physical_memory_space) {
        fprintf(stderr, "Failed to allocate physical memory space.\n");
        free(frame_bitmap);
        exit(1);
    }

    printf("PMM initialized with %zu frames.\n", total_frames);
}

void *pmm_allocate_frame() {
    for (size_t i = 0; i < total_frames; i++) {
        if (!frame_bitmap[i]) {
            frame_bitmap[i] = true;
            void *allocated_frame = (char *)physical_memory_space + i * PAGE_SIZE;
            printf("Allocated physical frame at index %zu, address %p\n", i, allocated_frame);
            return allocated_frame;
        }
    }

    printf("No more physical frames available.\n");
    return NULL;
}

void pmm_free_frame(void *frame_address) {
    // Cast both pointers to char* for pointer arithmetic and comparison
    char *frame_ptr = (char *)frame_address;
    char *memory_space_end = (char *)physical_memory_space + total_frames * PAGE_SIZE;
    
    if (!frame_address || frame_ptr < (char *)physical_memory_space || frame_ptr >= memory_space_end) {
        fprintf(stderr, "Invalid frame address: %p\n", frame_address);
        return;
    }

    size_t frame_index = ((char *)frame_address - (char *)physical_memory_space) / PAGE_SIZE;
    if (frame_bitmap[frame_index]) {
        frame_bitmap[frame_index] = false;
        printf("Freed physical frame at address %p (index %zu)\n", frame_address, frame_index);
    } else {
        fprintf(stderr, "Frame at address %p is already free.\n", frame_address);
    }
}