#include "kernel/paging.h"
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>

#define PAGE_TABLE_SIZE 1024

typedef struct PageTableEntry {
    void *virtual_address;
    void *physical_address;
    bool valid;
} PageTableEntry;

static PageTableEntry *page_table = NULL;
static size_t total_page_table_entries;

void paging_init(size_t total_pages) {
    total_page_table_entries = total_pages;
    page_table = calloc(total_page_table_entries, sizeof(PageTableEntry));
    if (!page_table) {
        fprintf(stderr, "Failed to initialize page table.\n");
        exit(1);
    }
    printf("Paging system initialized with %zu entries.\n", total_page_table_entries);
}

void add_page_table_entry(void *virtual_address, void *physical_address) {
    for (size_t i = 0; i < total_page_table_entries; i++) {
        if (!page_table[i].valid) {
            page_table[i].virtual_address = virtual_address;
            page_table[i].physical_address = physical_address;
            page_table[i].valid = true;
            printf("Added page table entry: VA %p -> PA %p\n", virtual_address, physical_address);
            return;
        }
    }
    fprintf(stderr, "Failed to add page table entry. No free entries available.\n");
}

void remove_page_table_entry(void *virtual_address) {
    for (size_t i = 0; i < total_page_table_entries; i++) {
        if (page_table[i].valid && page_table[i].virtual_address == virtual_address) {
            page_table[i].valid = false;
            printf("Removed page table entry for VA %p\n", virtual_address);
            return;
        }
    }
    fprintf(stderr, "Failed to remove page table entry. Virtual address %p not found.\n", virtual_address);
}

void *get_physical_address(void *virtual_address) {
    for (size_t i = 0; i < total_page_table_entries; i++) {
        if (page_table[i].valid && page_table[i].virtual_address == virtual_address) {
            return page_table[i].physical_address;
        }
    }
    fprintf(stderr, "Physical address for VA %p not found.\n", virtual_address);
    return NULL;
}
