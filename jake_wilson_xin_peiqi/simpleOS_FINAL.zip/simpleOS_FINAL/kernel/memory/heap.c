#include "kernel/heap.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <pthread.h>

static void *heap_memory = NULL;
static size_t heap_size;
static size_t allocated_size = 0;
static pthread_mutex_t heap_lock = PTHREAD_MUTEX_INITIALIZER;

typedef struct FreeNode {
    size_t size;
    struct FreeNode *next;
} FreeNode;

static FreeNode *free_list = NULL;

void heap_init(size_t size) {
    heap_memory = malloc(size);
    heap_size = size;
    allocated_size = 0;
    free_list = NULL;
    if (!heap_memory) {
        fprintf(stderr, "Failed to initialize heap memory.\n");
        exit(1);
    }
    printf("Heap initialized with size %zu bytes.\n", size);
}

void *heap_allocate(size_t size) {
    pthread_mutex_lock(&heap_lock);
    if (size == 0) {
        pthread_mutex_unlock(&heap_lock);
        return NULL;
    }

    size = (size + 7) & ~7;
    FreeNode **current = &free_list;
    while (*current) {
        if ((*current)->size >= size) {
            void *block = (void *)(*current);
            size_t remaining = (*current)->size - size;

            if (remaining > sizeof(FreeNode)) {
                FreeNode *new_node = (FreeNode *)((char *)block + size);
                new_node->size = remaining - sizeof(FreeNode);
                new_node->next = (*current)->next;
                *current = new_node;
            } else {
                *current = (*current)->next;
            }

            pthread_mutex_unlock(&heap_lock);
            return block;
        }
        current = &(*current)->next;
    }

    if (allocated_size + size > heap_size) {
        pthread_mutex_unlock(&heap_lock);
        return NULL;
    }
    void *allocated = (char *)heap_memory + allocated_size;
    allocated_size += size;
    pthread_mutex_unlock(&heap_lock);
    return allocated;
}

void heap_free(void *ptr) {
    if (!ptr) return;

    pthread_mutex_lock(&heap_lock);
    FreeNode *node = (FreeNode *)ptr;
    node->next = free_list;
    node->size = sizeof(node);
    free_list = node;
    pthread_mutex_unlock(&heap_lock);
    printf("Freed memory block at %p\n", ptr);
}
