#include "kernel/vmm.h"
#include "kernel/pmm.h"
#include "kernel/paging.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#define TOTAL_VIRTUAL_MEMORY 1024 * 1024 * 128 // 128 MB
#define PAGE_SIZE 4096

static void *virtual_memory_space = NULL;
static bool *page_bitmap = NULL;
static size_t total_pages = 0;

void vmm_init() {
    virtual_memory_space = malloc(TOTAL_VIRTUAL_MEMORY);
    if (!virtual_memory_space) {
        fprintf(stderr, "Failed to allocate virtual memory space.\n");
        exit(1);
    }

    total_pages = TOTAL_VIRTUAL_MEMORY / PAGE_SIZE;
    page_bitmap = calloc(total_pages, sizeof(bool));
    if (!page_bitmap) {
        fprintf(stderr, "Failed to allocate page bitmap.\n");
        free(virtual_memory_space);
        exit(1);
    }

    paging_init(total_pages); // Initialize paging system
    printf("VMM initialized with %zu pages.\n", total_pages);
}

void *vmm_allocate_page() {
    for (size_t i = 0; i < total_pages; i++) {
        if (!page_bitmap[i]) {
            page_bitmap[i] = true;
            void *allocated_page = (char *)virtual_memory_space + i * PAGE_SIZE;
            add_page_table_entry(allocated_page, pmm_allocate_frame());
            printf("Allocated virtual page at %p\n", allocated_page);
            return allocated_page;
        }
    }

    printf("No more virtual memory available.\n");
    return NULL;
}

void vmm_free_page(void *virtual_address) {
    if (!virtual_address || (char *)virtual_address < (char *)virtual_memory_space ||
        (char *)virtual_address >= (char *)virtual_memory_space + TOTAL_VIRTUAL_MEMORY) {
        fprintf(stderr, "Invalid virtual address: %p\n", virtual_address);
        return;
    }

    size_t page_index = ((char *)virtual_address - (char *)virtual_memory_space) / PAGE_SIZE;
    if (!page_bitmap[page_index]) {
        fprintf(stderr, "Virtual page at %p is not allocated.\n", virtual_address);
        return;
    }

    page_bitmap[page_index] = false;
    pmm_free_frame(get_physical_address(virtual_address));
    remove_page_table_entry(virtual_address);
    printf("Freed virtual page at %p\n", virtual_address);
}

void *vmm_translate(void *virtual_address) {
    if (!virtual_address || (char *)virtual_address < (char *)virtual_memory_space ||
        (char *)virtual_address >= (char *)virtual_memory_space + TOTAL_VIRTUAL_MEMORY) {
        fprintf(stderr, "Invalid virtual address for translation: %p\n", virtual_address);
        return NULL;
    }

    size_t page_index = ((char *)virtual_address - (char *)virtual_memory_space) / PAGE_SIZE;
    if (!page_bitmap[page_index]) {
        fprintf(stderr, "Page at %p is not allocated.\n", virtual_address);
        return NULL;
    }

    return get_physical_address(virtual_address);
}