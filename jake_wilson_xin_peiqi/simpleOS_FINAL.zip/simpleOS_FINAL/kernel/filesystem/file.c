#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "kernel/filesystem.h"

// file structure to represent an open file
typedef struct {
    // Associated inode number
    uint32_t inode;
    // Current file offset
    uint32_t offset;
    // File access flags
    int flags;
    // Whether file needs to be written back
    bool is_dirty;
    // Whether this file structure is in use
    bool is_used;
} file_t;

// array of open file structures
static file_t open_files[MAX_OPEN_FILES];
// flag to indicate if the file system has been initialized
static bool initialized = false;

// initialize the file system
void file_init(void) {
    // return if already initialized
    if (!initialized) {
        // reset all file structures to zero
        memset(open_files, 0, sizeof(open_files));
        // mark the file system as initialized
        initialized = true;
        // print a message indicating the file system has been initialized
        printf("\033[32m[File] System initialized\033[0m\n");
    }
}

// allocate a new file descriptor
int file_alloc(uint32_t inode_num, int flags) {
    // initialize the file system if it hasn't been done already
    if (!initialized) file_init();
    
    // find a free file structure
    for (int i = 0; i < MAX_OPEN_FILES; i++) {
        if (!open_files[i].is_used) {
            // initialize the file structure
            open_files[i].inode = inode_num;
            open_files[i].offset = 0;
            open_files[i].flags = flags;
            open_files[i].is_dirty = false;
            open_files[i].is_used = true;
            // print a message indicating a new file descriptor has been allocated
            printf("\033[32m[File] Allocated file descriptor %d for inode %u\033[0m\n", i, inode_num);
            // return the index of the allocated file descriptor
            return i;
        }
    }
    
    // no free file descriptors available
    printf("\033[31m[File] No free file descriptors available\033[0m\n");
    return -1;
}

// get the current offset of an open file
uint32_t file_get_offset(int fd) {
    // check if the file system is initialized and the file descriptor is valid
    if (!initialized || fd < 0 || fd >= MAX_OPEN_FILES || !open_files[fd].is_used) {
        return 0;
    }
    // return the current offset of the file
    return open_files[fd].offset;
}

// seek to a new position in an open file
int file_seek(int fd, off_t offset, int whence) {
    // check if the file system is initialized and the file descriptor is valid
    if (!initialized || fd < 0 || fd >= MAX_OPEN_FILES || !open_files[fd].is_used) {
        return -1;
    }
    
    // get the file structure
    file_t* file = &open_files[fd];
    // get the size of the file
    size_t file_size = inode_get_size(file->inode);
    // calculate the new offset based on the whence parameter
    off_t new_offset;
    switch (whence) {
        case SEEK_SET:
            new_offset = offset;
            break;
        case SEEK_CUR:
            new_offset = file->offset + offset;
            break;
        case SEEK_END:
            new_offset = file_size + offset;
            break;
        default:
            return -1;
    }
    
    // don't allow negative offset
    if (new_offset < 0) return -1;
    
    // update the file offset
    file->offset = new_offset;
    return 0;
}

// read from an open file
ssize_t file_read(int fd, void* buf, size_t count) {
    // check if the file system is initialized and the file descriptor is valid
    if (!initialized || fd < 0 || fd >= MAX_OPEN_FILES) return -1;
    if (!open_files[fd].is_used) return -1;
    // check if the buffer and count are valid
    if (!buf || count == 0) return 0;
    
    // get the file structure
    file_t* file = &open_files[fd];
    // get the size of the file
    size_t file_size = inode_get_size(file->inode);
    // initialize variables for the read operation
    size_t bytes_read = 0;
    char* data = (char*)buf;
    
    // return 0 if we've reached the end of the file
    if (file->offset >= file_size) {
        return 0;
    }
    
    // adjust the count to not read past the end of the file
    if (file->offset + count > file_size) {
        count = file_size - file->offset;
    }
    
    // read data from the file in block-sized chunks
    while (bytes_read < count) {
        uint32_t current_block = file->offset / BLOCK_SIZE;
        uint32_t offset_in_block = file->offset % BLOCK_SIZE;
        size_t remaining = count - bytes_read;
        size_t can_read = BLOCK_SIZE - offset_in_block;
        
        // limit the amount to read to the remaining bytes in the block
        if (can_read > remaining) {
            can_read = remaining;
        }
        
        // get the block and read data from the buffer
        int block_num = inode_get_block(file->inode, current_block);
        if (block_num < 0) break;
        buffer_t* buffer = buffer_get(block_num);
        if (!buffer) break;
        buffer_read(buffer, data + bytes_read, can_read, offset_in_block);
        buffer_release(buffer);
        
        // update the read counters and file offset
        bytes_read += can_read;
        file->offset += can_read;
    }
    
    // print a message indicating the number of bytes read
    printf("\033[32m[File] Read %zu bytes (offset=%u, size=%zu)\033[0m\n",
           bytes_read, file->offset, file_size);
    return bytes_read;
}

// write to an open file
ssize_t file_write(int fd, const void* buf, size_t count) {
    // check if the file system is initialized and the file descriptor is valid
    if (!initialized || fd < 0 || fd >= MAX_OPEN_FILES) return -1;
    if (!open_files[fd].is_used) return -1;
    // check if the buffer and count are valid
    if (!buf || count == 0) return 0;
    
    // get the file structure
    file_t* file = &open_files[fd];
    // initialize variables for the write operation
    size_t bytes_written = 0;
    const char* data = (const char*)buf;
    
    // write data to the file in block-sized chunks
    while (bytes_written < count) {
        uint32_t current_block = file->offset / BLOCK_SIZE;
        uint32_t offset_in_block = file->offset % BLOCK_SIZE;
        size_t remaining = count - bytes_written;
        size_t can_write = BLOCK_SIZE - offset_in_block;
        
        // limit the amount to write to the remaining bytes in the block
        if (can_write > remaining) {
            can_write = remaining;
        }
        
        // get or allocate the block and write data to the buffer
        int block_num = inode_get_block(file->inode, current_block);
        if (block_num < 0) {
            block_num = current_block;  // Simplified allocation
            if (inode_add_block(file->inode, block_num) < 0) {
                break;
            }
        }
        buffer_t* buffer = buffer_get(block_num);
        if (!buffer) break;
        buffer_write(buffer, data + bytes_written, can_write, offset_in_block);
        buffer_release(buffer);
        
        // update the write counters and file offset
        bytes_written += can_write;
        file->offset += can_write;
    }
    
    // update the file size if necessary
    size_t new_size = file->offset;
    if (new_size > inode_get_size(file->inode)) {
        inode_update_size(file->inode, new_size);
    }
    
    // mark the file as dirty
    file->is_dirty = true;
    // print a message indicating the number of bytes written
    printf("\033[32m[File] Wrote %zu bytes (offset=%u)\033[0m\n", bytes_written, file->offset);
    return bytes_written;
}

// close an open file
void file_close(int fd) {
    // check if the file system is initialized and the file descriptor is valid
    if (!initialized || fd < 0 || fd >= MAX_OPEN_FILES) return;
    if (!open_files[fd].is_used) return;
    
    // sync the file if it's dirty
    if (open_files[fd].is_dirty) {
        // would write back to disk in a real implementation
        printf("\033[32m[File] Syncing dirty file (fd=%d)\033[0m\n", fd);
    }
    
    // print a message indicating the file has been closed
    printf("\033[32m[File] Closed file descriptor %d\033[0m\n", fd);
    // reset the file structure
    memset(&open_files[fd], 0, sizeof(file_t));
}