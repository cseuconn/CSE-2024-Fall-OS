#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "kernel/filesystem.h"

// inode structure
typedef struct {
   // inode number
   uint32_t inode_num;
   // file type
   file_type_t type;
   // file size
   uint32_t size;
   // direct blocks
   uint32_t blocks[DIRECT_BLOCKS];
   // creation time
   time_t created;
   // modification time
   time_t modified;
   // last access time
   time_t accessed;
   // number of directory entries pointing to this inode
   uint32_t links;
   // number of blocks currently allocated
   uint32_t blocks_allocated;
   // whether the inode is in use
   bool is_used;
} inode_t;

// inode table
static inode_t inode_table[MAX_FILES];
// flag to indicate if the inode system has been initialized
static bool initialized = false;

// initialize the inode system
void inode_init(void) {
   // return if already initialized
   if (initialized) return;
   
   // reset the inode table
   memset(inode_table, 0, sizeof(inode_table));
   for (int i = 0; i < MAX_FILES; i++) {
       inode_table[i].inode_num = i;
       inode_table[i].is_used = false;
       inode_table[i].links = 0;
       inode_table[i].blocks_allocated = 0;
   }
   
   // mark the system as initialized
   initialized = true;
   printf("\033[32m[Inode] System initialized with %d inodes\033[0m\n", MAX_FILES);
}

// allocate a new inode
uint32_t inode_allocate(void) {
   // initialize the inode system if it hasn't been done already
   if (!initialized) {
       inode_init();
   }
   
   // find a free inode
   for (int i = 0; i < MAX_FILES; i++) {
       if (!inode_table[i].is_used) {
           inode_table[i].is_used = true;
           inode_table[i].created = time(NULL);
           inode_table[i].modified = inode_table[i].created;
           inode_table[i].accessed = inode_table[i].created;
           inode_table[i].links = 1;
           inode_table[i].size = 0;
           inode_table[i].blocks_allocated = 0;
           memset(inode_table[i].blocks, 0, sizeof(inode_table[i].blocks));
           
           printf("\033[32m[Inode] Allocated inode %d\033[0m\n", i);
           return i;
       }
   }
   
   // no free inodes available
   printf("\033[31m[Inode] Failed to allocate inode: no free inodes\033[0m\n");
   return -1;
}

// free an inode
void inode_free(uint32_t inode_num) {
   // return if the inode number is out of range
   if (inode_num >= MAX_FILES) return;
   
   inode_t* inode = &inode_table[inode_num];
   
   // free the inode if it is in use
   if (inode->is_used) {
       printf("\033[32m[Inode] Freed inode %u\033[0m\n", inode_num);
       memset(inode, 0, sizeof(inode_t));
       inode->inode_num = inode_num;
       inode->is_used = false;
   }
}

// get the block number for a given inode and block index
int inode_get_block(uint32_t inode_num, uint32_t block_index) {
   // return -1 if the inode number is out of range or the inode is not in use
   if (inode_num >= MAX_FILES || !inode_table[inode_num].is_used) {
       return -1;
   }
   
   // return -1 if the block index is out of range
   if (block_index >= DIRECT_BLOCKS) {
       return -1;
   }
   
   // return the block number
   return inode_table[inode_num].blocks[block_index];
}

// add a new block to an inode
int inode_add_block(uint32_t inode_num, uint32_t block_num) {
   // return -1 if the inode number is out of range or the inode is not in use
   if (inode_num >= MAX_FILES || !inode_table[inode_num].is_used) {
       return -1;
   }
   
   inode_t* inode = &inode_table[inode_num];
   // return -1 if the inode has reached the maximum number of direct blocks
   if (inode->blocks_allocated >= DIRECT_BLOCKS) {
       return -1;
   }
   
   // add the new block to the inode
   inode->blocks[inode->blocks_allocated] = block_num;
   inode->blocks_allocated++;
   inode->modified = time(NULL);
   return 0;
}

// get the size of an inode
size_t inode_get_size(uint32_t inode_num) {
   // return 0 if the inode number is out of range or the inode is not in use
   if (inode_num >= MAX_FILES || !inode_table[inode_num].is_used) {
       return 0;
   }
   
   // return the size of the inode
   return inode_table[inode_num].size;
}

// update the size of an inode
void inode_update_size(uint32_t inode_num, size_t new_size) {
   // return if the inode number is out of range or the inode is not in use
   if (inode_num >= MAX_FILES || !inode_table[inode_num].is_used) {
       return;
   }
   
   // update the inode size and modification time
   printf("\033[32m[Inode] Updating inode %u size from %u to %zu\033[0m\n",
          inode_num, inode_table[inode_num].size, new_size);
   inode_table[inode_num].size = new_size;
   inode_table[inode_num].modified = time(NULL);
}