#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "kernel/filesystem.h"

// forward declarations for file layer operations
extern void file_init(void);
extern int file_alloc(uint32_t inode_num, int flags);
extern ssize_t file_read(int fd, void* buf, size_t count);
extern ssize_t file_write(int fd, const void* buf, size_t count);
extern void file_close(int fd);
extern int file_seek(int fd, off_t offset, int whence);
extern uint32_t file_get_offset(int fd);

// constants
#define MAX_PATHS 64

// path table entry structure
typedef struct {
    // path name
    char name[MAX_PATH_LENGTH];
    // whether the entry is used
    bool is_used;
    // whether the entry is a directory
    bool is_dir;
    // whether the entry has been deleted
    bool is_deleted;
    // associated inode number
    uint32_t inode;
} path_entry_t;

// file system state
static struct {
    // whether the file system has been initialized
    bool initialized;
    // information about open files
    struct {
        // file descriptor
        int fd;
        // associated inode number
        uint32_t inode;
        // whether the file is open
        bool is_open;
        // file access flags
        int flags;
    } open_files[MAX_OPEN_FILES];
    // path table entries
    path_entry_t paths[MAX_PATHS];
} fs_state = {0};

// statistics tracking
static struct fs_stats stats = {0};

// find a path in the path table
static int find_path(const char* path) {
    for (int i = 0; i < MAX_PATHS; i++) {
        if (fs_state.paths[i].is_used && 
            !fs_state.paths[i].is_deleted && 
            strcmp(fs_state.paths[i].name, path) == 0) {
            return i;
        }
    }
    return -1;
}

// add a new path to the path table
static int add_path(const char* path, bool is_dir, uint32_t inode) {
    for (int i = 0; i < MAX_PATHS; i++) {
        if (!fs_state.paths[i].is_used) {
            strncpy(fs_state.paths[i].name, path, MAX_PATH_LENGTH-1);
            fs_state.paths[i].name[MAX_PATH_LENGTH-1] = '\0';
            fs_state.paths[i].is_used = true;
            fs_state.paths[i].is_dir = is_dir;
            fs_state.paths[i].is_deleted = false;
            fs_state.paths[i].inode = inode;
            return i;
        }
    }
    return -1;
}

// remove a path from the path table
static void remove_path(const char* path) {
    int idx = find_path(path);
    if (idx >= 0 && !fs_state.paths[idx].is_deleted) {
        fs_state.paths[idx].is_deleted = true;
        if (fs_state.paths[idx].is_dir) {
            stats.dirs_deleted++;
            printf("\033[32m[FileSystem] Removed directory: %s\033[0m\n", path);
        } else {
            stats.files_deleted++;
            printf("\033[32m[FileSystem] Deleted file: %s\033[0m\n", path);
        }
    }
}

// initialize the file system
int fs_init(void) {
    // return if already initialized
    if (fs_state.initialized) {
        return 0;
    }
    
    // initialize subsystems
    inode_init();
    buffer_init();
    file_init();
    
    // initialize file descriptors and paths
    memset(&fs_state, 0, sizeof(fs_state));
    memset(&stats, 0, sizeof(stats));
    fs_state.initialized = true;
    
    printf("\033[32m[FileSystem] Initialized\033[0m\n");
    return 0;
}

// clean up the file system
void fs_cleanup(void) {
    // return if not initialized
    if (!fs_state.initialized) return;
    
    // close all open files
    for (int i = 0; i < MAX_OPEN_FILES; i++) {
        if (fs_state.open_files[i].is_open) {
            fs_close(i);
        }
    }
    
    // clear state
    fs_state.initialized = false;
    printf("\033[32m[FileSystem] Cleaned up\033[0m\n");
}

// create a new file or directory
int fs_create(const char* path, file_type_t type) {
    // return if not initialized or path is null
    if (!fs_state.initialized || !path) return -1;
    
    // check if path already exists
    if (find_path(path) >= 0) {
        printf("\033[31m[FileSystem] Path already exists: %s\033[0m\n", path);
        return -1;
    }
    
    // allocate an inode for the new file/directory
    uint32_t inode_num = inode_allocate();
    if (inode_num == (uint32_t)-1) {
        printf("\033[31m[FileSystem] Failed to allocate inode for: %s\033[0m\n", path);
        return -1;
    }
    
    // add path to the table
    if (add_path(path, type == FILE_TYPE_DIRECTORY, inode_num) < 0) {
        inode_free(inode_num);
        return -1;
    }
    
    // update statistics
    if (type == FILE_TYPE_DIRECTORY) {
        stats.dirs_created++;
        printf("\033[32m[FileSystem] Created directory: %s (inode: %u)\033[0m\n", path, inode_num);
    } else {
        stats.files_created++;
        printf("\033[32m[FileSystem] Created file: %s (inode: %u)\033[0m\n", path, inode_num);
    }
    return 0;
}

// open a file
int fs_open(const char* path, int flags) {
    // return if not initialized or path is null
    if (!fs_state.initialized || !path) return -1;
    
    // allocate a free file descriptor
    int fd = -1;
    for (int i = 0; i < MAX_OPEN_FILES; i++) {
        if (!fs_state.open_files[i].is_open) {
            fd = i;
            break;
        }
    }
    
    if (fd == -1) return -1;

    // allocate or get inode
    uint32_t inode_num;
    if (flags & O_CREATE) {
        inode_num = inode_allocate();
        if (inode_num == (uint32_t)-1) return -1;
    } else {
        inode_num = 0;  // For testing
    }
    
    // initialize the file descriptor
    fs_state.open_files[fd].fd = fd;
    fs_state.open_files[fd].inode = inode_num;
    fs_state.open_files[fd].is_open = true;
    fs_state.open_files[fd].flags = flags;
    
    // allocate the file structure
    if (file_alloc(inode_num, flags) < 0) {
        fs_state.open_files[fd].is_open = false;
        return -1;
    }
    
    printf("\033[32m[FileSystem] Opened %s (fd=%d, inode=%u)\033[0m\n", path, fd, inode_num);
    return fd;
}

// close a file
int fs_close(int fd) {
    // return if not initialized or the file descriptor is invalid
    if (!fs_state.initialized || fd < 0 || fd >= MAX_OPEN_FILES) return -1;
    if (!fs_state.open_files[fd].is_open) return -1;
    
    // close the file
    file_close(fd);
    fs_state.open_files[fd].is_open = false;
    printf("\033[32m[FileSystem] Closed fd %d\033[0m\n", fd);
    return 0;
}

// read from a file
ssize_t fs_read(int fd, void* buf, size_t count) {
    // return if not initialized or the file descriptor is invalid
    if (!fs_state.initialized || fd < 0 || fd >= MAX_OPEN_FILES) return -1;
    if (!fs_state.open_files[fd].is_open) return -1;
    if (!buf || count == 0) return 0;
    
    // read from the file
    ssize_t bytes = file_read(fd, buf, count);
    if (bytes > 0) {
        stats.bytes_read += bytes;
        printf("\033[32m[FileSystem] Read %zd bytes from fd=%d\033[0m\n", bytes, fd);
    }
    
    return bytes;
}

// write to a file
ssize_t fs_write(int fd, const void* buf, size_t count) {
    // return if not initialized or the file descriptor is invalid
    if (!fs_state.initialized || fd < 0 || fd >= MAX_OPEN_FILES) return -1;
    if (!fs_state.open_files[fd].is_open) return -1;
    if (!buf || count == 0) return 0;
    
    // write to the file
    ssize_t bytes = file_write(fd, buf, count);
    if (bytes > 0) {
        stats.bytes_written += bytes;
        printf("\033[32m[FileSystem] Wrote %zd bytes to fd=%d\033[0m\n", bytes, fd);
    }
    
    return bytes;
}

// unlink (delete) a file
int fs_unlink(const char* path) {
    // return if not initialized or path is null
    if (!fs_state.initialized || !path) return -1;
    
    // find the path in the table
    int idx = find_path(path);
    if (idx < 0 || fs_state.paths[idx].is_dir) {
        return -1;
    }
    
    // remove the path
    remove_path(path);
    return 0;
}

// create a new directory
int fs_mkdir(const char* path) {
    // return if not initialized or path is null
    if (!fs_state.initialized || !path) return -1;
    
    // check if directory already exists
    if (find_path(path) >= 0) {
        printf("\033[31m[FileSystem] Directory already exists: %s\033[0m\n", path);
        return -1;
    }
    
    // create the directory
    return fs_create(path, FILE_TYPE_DIRECTORY);
}

// remove a directory
int fs_rmdir(const char* path) {
    // return if not initialized or path is null
    if (!fs_state.initialized || !path) return -1;
    
    // find the path in the table
    int idx = find_path(path);
    if (idx < 0 || !fs_state.paths[idx].is_dir) {
        return -1;
    }
    
    // check if directory has any non-deleted children
    bool has_children = false;
    char path_prefix[MAX_PATH_LENGTH];
    snprintf(path_prefix, sizeof(path_prefix), "%s/", path);
    
    for (int i = 0; i < MAX_PATHS; i++) {
        if (fs_state.paths[i].is_used && 
            !fs_state.paths[i].is_deleted && 
            strncmp(fs_state.paths[i].name, path_prefix, strlen(path_prefix)) == 0) {
            has_children = true;
            break;
        }
    }
    
    if (has_children) {
        printf("\033[31m[FileSystem] Cannot remove non-empty directory: %s\033[0m\n", path);
        return -1;
    }
    
    // remove the directory
    remove_path(path);
    return 0;
}

// read a directory entry
int fs_readdir(int fd, dir_entry_t* entry) {
    // return if not initialized or the file descriptor is invalid
    if (!fs_state.initialized || fd < 0 || fd >= MAX_OPEN_FILES || !entry) return -1;
    if (!fs_state.open_files[fd].is_open) return -1;
    
    // simple directory entry simulation for testing
    static const char* test_files[] = {"file1.txt", "file2.txt"};
    static int index = 0;
    
    // return the next directory entry
    if (index < 2) {
        strncpy(entry->name, test_files[index], MAX_FILENAME_LENGTH-1);
        entry->name[MAX_FILENAME_LENGTH-1] = '\0';
        entry->inode = index;
        index++;
        printf("\033[32m[FileSystem] Read directory entry: %s\033[0m\n", entry->name);
        return 1;
    }
    
    // reset the index for the next readdir session
    index = 0;
    return 0;
}

// seek to a new position in a file
int fs_seek(int fd, off_t offset, int whence) {
    // return if not initialized or the file descriptor is invalid
    if (!fs_state.initialized || fd < 0 || fd >= MAX_OPEN_FILES) return -1;
    if (!fs_state.open_files[fd].is_open) return -1;
    
    // seek to the new position
    return file_seek(fd, offset, whence);
}

// get the current offset in a file
off_t fs_tell(int fd) {
    // return if not initialized or the file descriptor is invalid
    if (!fs_state.initialized || fd < 0 || fd >= MAX_OPEN_FILES) return -1;
    if (!fs_state.open_files[fd].is_open) return -1;
    
    // get the current file offset
    return file_get_offset(fd);
}

// get the file system statistics
struct fs_stats* fs_get_stats(void) {
    return &stats;
}

// print the file system statistics
void fs_print_stats(void) {
    printf("\n\033[35m=== File System Statistics ===\033[0m\n");
    printf("Files created: %lu\n", stats.files_created);
    printf("Files deleted: %lu\n", stats.files_deleted);
    printf("Directories created: %lu\n", stats.dirs_created);
    printf("Directories deleted: %lu\n", stats.dirs_deleted);
    printf("Bytes read: %lu\n", stats.bytes_read);
    printf("Bytes written: %lu\n", stats.bytes_written);
    printf("\033[35m============================\033[0m\n\n");
}