#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "kernel/filesystem.h"

// buffer cache structure to manage all buffers, the free list, and the hash table
static struct {
    // array of buffers in the cache
    buffer_t buffers[NUM_BUFFERS];
    // pointer to the list of free buffers
    buffer_t* free_list;
    // hash table for fast buffer lookups
    buffer_t* hash_table[NUM_BUFFERS];
    // indicates if the buffer cache has been initialized
    bool initialized;
} buffer_cache = {0};

// initializes the buffer cache, creating the free list and hash table
void buffer_init(void) {
    // return if already initialized
    if (buffer_cache.initialized) return;
    
    // reset all fields to zero
    memset(&buffer_cache, 0, sizeof(buffer_cache));
    
    // link buffers into a free list and set their default properties
    for (int i = 0; i < NUM_BUFFERS - 1; i++) {
        // link to the next buffer
        buffer_cache.buffers[i].next = &buffer_cache.buffers[i + 1];
        // mark buffer as invalid
        buffer_cache.buffers[i].valid = false;
        // mark buffer as clean
        buffer_cache.buffers[i].dirty = false;
        // clear buffer data
        memset(buffer_cache.buffers[i].data, 0, BLOCK_SIZE);
    }
    
    // set head of free list
    buffer_cache.free_list = &buffer_cache.buffers[0];
    // clear hash table
    memset(buffer_cache.hash_table, 0, sizeof(buffer_cache.hash_table));
    
    // mark the cache as initialized
    buffer_cache.initialized = true;
    // print a message indicating the number of initialized buffers
    printf("\033[32m[Buffer Cache] Initialized with %d buffers\033[0m\n", NUM_BUFFERS);
}

// get a buffer for the given block number
buffer_t* buffer_get(uint32_t block_num) {
    // initialize the buffer cache if it hasn't been done already
    if (!buffer_cache.initialized) {
        buffer_init();
    }
    
    // calculate the hash index for the given block number
    uint32_t hash_index = block_num % NUM_BUFFERS;
    // get the first buffer in the hash chain
    buffer_t* buf = buffer_cache.hash_table[hash_index];
    
    // traverse the hash chain to find the buffer for the given block number
    while (buf) {
        // check if the buffer matches the block number and is valid
        if (buf->block_num == block_num && buf->valid) {
            // only print for the first few blocks
            if (buf->block_num < 5) {
                printf("\033[32m[Buffer Cache] Hit for block %u\033[0m\n", block_num);
            }
            // return the found buffer
            return buf;
        }
        // move to the next buffer in the hash chain
        buf = buf->next;
    }
    
    // buffer not found in the hash table, allocate a new one
    if (buffer_cache.free_list) {
        // get the first buffer from the free list
        buf = buffer_cache.free_list;
        // remove the buffer from the free list
        buffer_cache.free_list = buf->next;
        
        // remove the buffer from the old hash chain if it was previously valid
        if (buf->valid) {
            buffer_t** pp = &buffer_cache.hash_table[buf->block_num % NUM_BUFFERS];
            while (*pp && *pp != buf) pp = &(*pp)->next;
            if (*pp) *pp = (*pp)->next;
        }
        
        // initialize the new buffer
        buf->block_num = block_num;
        buf->valid = true;
        buf->dirty = false;
        memset(buf->data, 0, BLOCK_SIZE);
        
        // add the new buffer to the hash chain
        buf->next = buffer_cache.hash_table[hash_index];
        buffer_cache.hash_table[hash_index] = buf;
        
        // only print for the first few blocks
        if (block_num < 5) {
            printf("\033[32m[Buffer Cache] Allocated new buffer for block %u\033[0m\n", block_num);
        }
        // return the newly allocated buffer
        return buf;
    }
    
    // no free buffers available
    printf("\033[31m[Buffer Cache] No free buffers available\033[0m\n");
    return NULL;
}

// read data from a buffer
void buffer_read(buffer_t* buf, void* data, size_t size, size_t offset) {
    // check if the buffer, data, and offset are valid
    if (!buf || !data || !buf->valid || offset >= BLOCK_SIZE) return;
    
    // limit read size to block boundary
    if (offset + size > BLOCK_SIZE) {
        size = BLOCK_SIZE - offset;
    }
    
    // copy data from the buffer to the provided data buffer
    memcpy(data, buf->data + offset, size);
}

// write data to a buffer
void buffer_write(buffer_t* buf, const void* data, size_t size, size_t offset) {
    // check if the buffer, data, and offset are valid
    if (!buf || !data || !buf->valid || offset >= BLOCK_SIZE) return;
    
    // limit write size to block boundary
    if (offset + size > BLOCK_SIZE) {
        size = BLOCK_SIZE - offset;
    }
    
    // copy data from the provided data buffer to the buffer
    memcpy(buf->data + offset, data, size);
    // mark the buffer as dirty
    buf->dirty = true;
}

// release a buffer back to the free list
void buffer_release(buffer_t* buffer) {
    // check if the buffer is valid
    if (!buffer) return;
    
    // if buffer is dirty, write it back (in a real implementation)
    if (buffer->dirty) {
        // only print for the first few blocks
        if (buffer->block_num < 5) {
            printf("\033[32m[Buffer Cache] Writing back dirty buffer for block %u\033[0m\n", 
                   buffer->block_num);
        }
        // mark the buffer as clean
        buffer->dirty = false;
    }
    
    // add the buffer to the free list
    buffer->next = buffer_cache.free_list;
    buffer_cache.free_list = buffer;
    // only print for the first few blocks
    if (buffer->block_num < 5) {
        printf("\033[32m[Buffer Cache] Released buffer for block %u\033[0m\n", buffer->block_num);
    }
}

// mark a buffer as dirty
void buffer_mark_dirty(buffer_t* buf) {
    // check if the buffer is valid
    if (buf && buf->valid) {
        // mark the buffer as dirty
        buf->dirty = true;
        // only print for the first few blocks
        if (buf->block_num < 5) {
            printf("\033[32m[Buffer Cache] Marked buffer for block %u as dirty\033[0m\n", 
                   buf->block_num);
        }
    }
}