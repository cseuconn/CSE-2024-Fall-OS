#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include "kernel/semaphore.h"
#include "kernel/process.h"

// This is used to track thread data
static struct 
{
    int total_waits;
    int total_signals;
    int total_timeouts;
} sem_stats = {0};

//create the semaphore
semaphore_t* semaphore_create(int initial_value) 
{
    //allocate memory and initialize the semaphore
    semaphore_t* sem = (semaphore_t*)malloc(sizeof(semaphore_t));
    //check to see if it was initialized correctly
    if (!sem) return NULL;
    
    //set correct pointers
    sem->value = initial_value;
    sem->waiters = NULL;
    sem->waiter_count = 0;
    
    //initialize everthing
    pthread_mutex_init(&sem->mutex, NULL);
    pthread_cond_init(&sem->cond, NULL);
    
    return sem;
}

//creation of a wait function
int semaphore_wait(semaphore_t* sem) 
{
    //checks to see if semaphore was initiazlized correctly
    if (!sem) return -1;
    
    //sets a lock using mutex
    pthread_mutex_lock(&sem->mutex);
    
    //while there are no threads using the semaphore
    while (sem->value <= 0) 
    {
        // Add current process to waiter list
        pcb_t* current = process_get_current();
        waiters_t* waiter = (waiters_t*)malloc(sizeof(waiters_t));
        //sets all of the correct pointers
        waiter->process = current;
        waiter->next = sem->waiters;
        sem->waiters = waiter;
        sem->waiter_count++;
        
        sem_stats.total_waits++;
        
        //use the wait function
        pthread_cond_wait(&sem->cond, &sem->mutex);
        
        // Remove from waiter list when woken
        sem->waiter_count--;
    }
    
    sem->value--;
    //unlock mutex 
    pthread_mutex_unlock(&sem->mutex);
    return 0;
}

//creating the signal function
int semaphore_signal(semaphore_t* sem) 
{
    //checks to see if semaphore was initilized correctly
    if (!sem) return -1;
    
    //locks mutex
    pthread_mutex_lock(&sem->mutex);
    
    sem->value++;
    sem_stats.total_signals++;
    
    // Wakes a process if one is waiting
    if (sem->waiters) 
    {
        pthread_cond_signal(&sem->cond);
    }
    
    pthread_mutex_unlock(&sem->mutex);
    return 0;
}

//this will keep track of the value of semaphore
int semaphore_value(semaphore_t* sem) 
{
    if (!sem) return -1;
    // again checks to see if semaphore was initizlized 
    return sem->value;
}

//destruction function creation
void semaphore_destroy(semaphore_t* sem) 
{
    if (!sem) return;
    
    pthread_mutex_destroy(&sem->mutex);
    pthread_cond_destroy(&sem->cond);
    
    // Free waiter list
    waiters_t* current = sem->waiters;
    while (current) 
    {
        waiters_t* next = current->next;
        free(current);
        current = next;
    }
    
    free(sem);
}

void print_semaphore_stats() 
{
    printf("\n=== Semaphore Statistics ===\n");
    printf("Total waits: %d\n", sem_stats.total_waits);
    printf("Total signals: %d\n", sem_stats.total_signals);
    printf("Total timeouts: %d\n", sem_stats.total_timeouts);
    printf("==========================\n\n");
}