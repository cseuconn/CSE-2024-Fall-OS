#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <pthread.h>
#include "kernel/mutex.h"
#include "kernel/process.h"

// Statistics tracking
static struct
{
    int total_locks;
    int total_unlocks;
    int wait_time;  // In milliseconds
} mutex_stats = {0};


//This makes the mutex lock
mutex_t* mutex_create() 
{
    //I am initializing mutex and am allocating the memory to the pointer
    mutex_t* mutex = (mutex_t*)malloc(sizeof(mutex_t));
    //This checks to see if the memory allocation worked
    if (!mutex) return NULL;
    
    //setting the pointers of the lock to the correct state 
    mutex->locked = false;
    mutex->owner = NULL;
    mutex->waiters = NULL;
    mutex->wait_count = 0;
    
    //Sets up the cond varible and initilized the mutex
    pthread_mutex_init(&mutex->impl_mutex, NULL);
    pthread_cond_init(&mutex->impl_cond, NULL);
    
    return mutex;
}

//Creating a locking functionality
int mutex_lock(mutex_t* mutex) 
{
    //check to see if memory allocation already happened if not return -1
    if (!mutex) return -1;
    
    //aquires the lock from the address 
    pthread_mutex_lock(&mutex->impl_mutex);
    
    // If mutex is already locked
    if (mutex->locked) 
    {
        
        // Add current process to waiter list pcb_t comes from process.c which was implemented
        pcb_t* current = process_get_current();
        // allocated the memory for the pointer and assignes it
        waiters_t* waiter = (waiters_t*)malloc(sizeof(waiters_t));
        //set waiter pointers and updates mutex 
        waiter->process = current;
        waiter->next = mutex->waiters;
        mutex->waiters = waiter;
        mutex->wait_count++;
        
        // while mutex is locked
        while (mutex->locked) 
        {
            //makes the thread wait untill condition is fulfilled
            pthread_cond_wait(&mutex->impl_cond, &mutex->impl_mutex);
        }
        
        // Remove from waiter list
        mutex->wait_count--;
    }
    
    //sets the mutex status to locked
    mutex->locked = true;
    //sets the thread that is accessing it to current owner
    mutex->owner = process_get_current();
    //updates stats
    mutex_stats.total_locks++;
    
    //unlock the mutex
    pthread_mutex_unlock(&mutex->impl_mutex);
    return 0;
}

//mutex unlock functionality
int mutex_unlock(mutex_t* mutex) 
{
    //check to see if mutex was initialized
    if (!mutex) return -1;
    
    //locks the lock
    pthread_mutex_lock(&mutex->impl_mutex);
    
    // Verify the current process owns the mutex
    if (mutex->owner != process_get_current()) 
    {
        pthread_mutex_unlock(&mutex->impl_mutex);
        return -1;
    }
    
    //sets the mutex pointers to the correct state
    mutex->locked = false;
    mutex->owner = NULL;
    mutex_stats.total_unlocks++;
    
    // Signal one waiting process
    if (mutex->waiters) 
    {
        //signal thread
        pthread_cond_signal(&mutex->impl_cond);
    }
    
    pthread_mutex_unlock(&mutex->impl_mutex);
    return 0;
}

//destroys the lock
void mutex_destroy(mutex_t* mutex) 
{
    //checks to see if mutex was correctly intitialized 
    if (!mutex) return;
    
    //destroys the lock 
    pthread_mutex_destroy(&mutex->impl_mutex);
    pthread_cond_destroy(&mutex->impl_cond);
    
    //frees the list of waiters 
    waiters_t* current = mutex->waiters;
    while (current) 
    {
        //this will go and free every waiting thread in the list
        waiters_t* next = current->next;
        free(current);
        current = next;
    }
    
    free(mutex);
}

void print_mutex_stats() 
{
    printf("\n=== Mutex Statistics ===\n");
    printf("Total locks acquired: %d\n", mutex_stats.total_locks);
    printf("Total unlocks: %d\n", mutex_stats.total_unlocks); 
}