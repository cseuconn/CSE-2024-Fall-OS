#ifndef PROCESS_H
#define PROCESS_H

#include <pthread.h>
#include <stdint.h>
#include <stdbool.h>

// Maximum number of processes
#define MAX_PROCESSES 5

// Process states
typedef enum {
    READY,
    RUNNING,
    WAITING,
    TERMINATED
} process_state_t;


// Process Control Block
typedef struct pcb {
    int pid;                        // Process ID
    process_state_t state;          // Current state
    pthread_t thread;               // Actual thread running the process
    void (*entry)(void);            // Entry point function
    struct pcb* next;               // For ready queue
    int priority;                   // Process priority (added)
    int time_quantum;              // Time quantum for RR (added)
} pcb_t;

// Process management API
int process_init(void);
int process_create(void (*entry)(void));
void process_yield(void);
pcb_t* process_get_current(void);
void process_cleanup(void);
void process_print_stats(void);
void process_cleanup(void);
pthread_mutex_t* get_scheduler_lock(void);
pcb_t* get_ready_queue(void);
pcb_t* get_current_process(void);

// Process priority levels
#define PRIORITY_HIGH     0
#define PRIORITY_NORMAL   1
#define PRIORITY_LOW      2
#define PRIORITY_IDLE     3

#endif