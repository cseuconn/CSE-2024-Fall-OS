#ifndef HEAP_H
#define HEAP_H

#include <stddef.h>

void heap_init(size_t size);
void *heap_allocate(size_t size);
void heap_free(void *ptr);

#endif // end HEAP_H