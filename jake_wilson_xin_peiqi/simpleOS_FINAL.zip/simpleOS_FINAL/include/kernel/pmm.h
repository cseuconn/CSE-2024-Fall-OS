/* Updated pmm.h */
#ifndef PMM_H
#define PMM_H

#include <stddef.h>

#define PAGE_SIZE 4096  // Define page size here

// Initialize physical memory manager
void pmm_init(size_t total_frames);

// Allocate a physical frame
void *pmm_allocate_frame();

// Free a physical frame
void pmm_free_frame(void *frame_address);

#endif // PMM_H

