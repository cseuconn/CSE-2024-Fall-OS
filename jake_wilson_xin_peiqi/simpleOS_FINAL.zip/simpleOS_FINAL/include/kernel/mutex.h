#ifndef MUTEX_H
#define MUTEX_H

#include <stdbool.h>
#include <pthread.h>
#include "kernel/process.h"

// Waiter list node
typedef struct waiters {
    pcb_t* process;
    struct waiters* next;
} waiters_t;

// Mutex structure
typedef struct mutex {
    bool locked;
    pcb_t* owner;
    waiters_t* waiters;
    int wait_count;
    pthread_mutex_t impl_mutex;
    pthread_cond_t impl_cond;
} mutex_t;

// Mutex API
mutex_t* mutex_create(void);
int mutex_lock(mutex_t* mutex);
int mutex_unlock(mutex_t* mutex);
void mutex_destroy(mutex_t* mutex);
void print_mutex_stats(void);

#endif 