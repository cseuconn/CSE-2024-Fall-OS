#ifndef PAGING_H
#define PAGING_H

#include <stddef.h>

// Initialize paging system
void paging_init(size_t total_pages);

// Add a page table entry
void add_page_table_entry(void *virtual_address, void *physical_address);

// Remove a page table entry
void remove_page_table_entry(void *virtual_address);

// Get physical address corresponding to a virtual address
void *get_physical_address(void *virtual_address);

#endif // PAGING_H