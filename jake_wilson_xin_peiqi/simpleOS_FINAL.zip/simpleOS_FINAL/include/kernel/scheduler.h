#ifndef SCHEDULER_H
#define SCHEDULER_H

#include "kernel/process.h"

// Scheduling algorithm types
typedef enum {
    SCHED_TYPE_RR,        /* Round Robin */
    SCHED_TYPE_FCFS,      /* First Come First Serve */
    SCHED_TYPE_PRIORITY   /* Priority based */
} sched_type_t;

// Scheduler API
void scheduler_init(void);
pcb_t* schedule_next_process(pcb_t* ready_queue);
void set_scheduling_algorithm(sched_type_t type);
void set_time_quantum(int quantum_ms);
void print_scheduler_stats(void);

// Configuration
#define DEFAULT_TIME_QUANTUM 100  /* Default time slice in milliseconds */
#define MIN_TIME_QUANTUM 10       /* Minimum allowed time quantum */
#define MAX_TIME_QUANTUM 1000     /* Maximum allowed time quantum */

#endif