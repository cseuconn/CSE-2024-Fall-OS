#ifndef VMM_H
#define VMM_H

#include <stddef.h>

// Virtual memory manager initialization
void vmm_init();

// Allocate a virtual page, return a pointer (start)
void *vmm_allocate_page();

// Free a virtual page
void vmm_free_page(void *virtual_address);

// Translate a virtual address to a physical address
void *vmm_translate(void *virtual_address);

#endif // END VMM_H
