#ifndef FILESYSTEM_H
#define FILESYSTEM_H

#include <stdint.h>
#include <stdbool.h>
#include <sys/types.h>
#include <time.h>

// ================ Constants ================
// File system limits
#define MAX_FILES 64
#define MAX_FILENAME_LENGTH 32
#define MAX_PATH_LENGTH 256
#define MAX_OPEN_FILES 16

// Storage parameters
#define BLOCK_SIZE 512
#define MAX_FILE_SIZE (1024 * 1024)  // 1MB
#define NUM_BUFFERS 64

// Inode parameters
#define DIRECT_BLOCKS 10
#define INDIRECT_BLOCKS 1

// Error codes
#define FS_SUCCESS 0
#define FS_ERROR -1
#define FS_EOF 0

// ================ Type Definitions ================
// Forward declarations
struct buffer;
typedef struct buffer buffer_t;

// File types
typedef enum {
    FILE_TYPE_REGULAR,
    FILE_TYPE_DIRECTORY,
    FILE_TYPE_SPECIAL
} file_type_t;

// File permissions
typedef enum {
    PERM_READ = 1,
    PERM_WRITE = 2,
    PERM_EXECUTE = 4
} file_perm_t;

// File flags
typedef enum {
    O_READ = 0x01,
    O_WRITE = 0x02,
    O_CREATE = 0x04,
    O_APPEND = 0x08,
    O_DIRECTORY = 0x10
} file_flags_t;

// Buffer cache entry
struct buffer {
    uint32_t block_num;
    uint8_t data[BLOCK_SIZE];
    bool dirty;
    bool valid;
    struct buffer* next;
};

// File status structure
typedef struct {
    uint32_t inode;            // Inode number
    uint32_t size;            // File size
    file_type_t type;         // File type
    uint32_t permissions;     // File permissions
    time_t created;           // Creation time
    time_t modified;          // Last modification time
    time_t accessed;          // Last access time
} file_stat_t;

// Directory entry structure
typedef struct {
    char name[MAX_FILENAME_LENGTH];
    uint32_t inode;
} dir_entry_t;

// Statistics structure
struct fs_stats {
    unsigned long files_created;
    unsigned long files_deleted;
    unsigned long dirs_created;
    unsigned long dirs_deleted;
    unsigned long bytes_read;
    unsigned long bytes_written;
};

// ================ Function Declarations ================
// Core filesystem operations
int fs_init(void);
void fs_cleanup(void);
struct fs_stats* fs_get_stats(void);
void fs_print_stats(void);

// File operations
int fs_create(const char* path, file_type_t type);
int fs_open(const char* path, int flags);
int fs_close(int fd);
ssize_t fs_read(int fd, void* buf, size_t count);
ssize_t fs_write(int fd, const void* buf, size_t count);
int fs_unlink(const char* path);
int fs_stat(const char* path, file_stat_t* stat);
int fs_seek(int fd, off_t offset, int whence);
off_t fs_tell(int fd);

// Directory operations
int fs_mkdir(const char* path);
int fs_rmdir(const char* path);
int fs_readdir(int fd, dir_entry_t* entry);

// Inode operations
void inode_init(void);
uint32_t inode_allocate(void);
void inode_free(uint32_t inode_num);
int inode_get_block(uint32_t inode_num, uint32_t block_index);
int inode_add_block(uint32_t inode_num, uint32_t block_num);
size_t inode_get_size(uint32_t inode_num);
void inode_update_size(uint32_t inode_num, size_t new_size);

// Buffer cache operations
void buffer_init(void);
buffer_t* buffer_get(uint32_t block_num);
void buffer_release(buffer_t* buffer);
void buffer_mark_dirty(buffer_t* buf);
void buffer_read(buffer_t* buf, void* data, size_t size, size_t offset); 
void buffer_write(buffer_t* buf, const void* data, size_t size, size_t offset); 

// File abstraction operations
void file_init(void);
int file_alloc(uint32_t inode_num, int flags);
ssize_t file_read(int fd, void* buf, size_t count);
ssize_t file_write(int fd, const void* buf, size_t count);
void file_close(int fd);

#endif /* FILESYSTEM_H */