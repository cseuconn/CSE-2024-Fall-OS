#ifndef SEMAPHORE_H
#define SEMAPHORE_H

#include <pthread.h>
#include "kernel/process.h"
#include "kernel/mutex.h"

// Semaphore structure
typedef struct semaphore {
    int value;
    waiters_t* waiters;
    int waiter_count;
    pthread_mutex_t mutex;
    pthread_cond_t cond;
} semaphore_t;

// Semaphore API
semaphore_t* semaphore_create(int initial_value);
int semaphore_wait(semaphore_t* sem);
int semaphore_signal(semaphore_t* sem);
int semaphore_value(semaphore_t* sem);
void semaphore_destroy(semaphore_t* sem);
void print_semaphore_stats(void);

#endif